import {
  IconLock,
  IconRefresh,
  IconShield,
  IconSpark,
  Stars,
} from "@/components/Brand";
import { getReviews, getReviewStats } from "@/lib/data";

const FALLBACK = [
  {
    id: 1,
    author: "Ron L.",
    quote: "An absolute game-changer when it comes to resolving disputes.",
    rating: 5,
    tag: "Verified user",
    createdAt: new Date(),
  },
  {
    id: 2,
    author: "John M.",
    quote: "After the 1st round, my score shot up over 220 points.",
    rating: 5,
    tag: "Score up 220 pts",
    createdAt: new Date(),
  },
  {
    id: 3,
    author: "Remy A.",
    quote:
      "I recommend this service to all my friends and family. It really works!",
    rating: 5,
    tag: "Verified user",
    createdAt: new Date(),
  },
  {
    id: 4,
    author: "Irvin J.",
    quote:
      "The platform's user-friendly interface made it incredibly easy for me.",
    rating: 5,
    tag: "Verified user",
    createdAt: new Date(),
  },
];

type ReviewCard = {
  id: number;
  author: string;
  quote: string;
  rating: number;
  tag: string;
  createdAt: Date;
};

const PILLARS = [
  {
    icon: <IconShield width={22} height={22} />,
    title: "110% Money-Back Guarantee",
    body: "We believe in the quality of our products. If KyKyDispute doesn't help you improve your credit after a year, we return 110% (yes, 110!) of your money.",
  },
  {
    icon: <IconLock width={22} height={22} />,
    title: "Secure & Reliable",
    body: "Our platform holds the highest standards of security, and our customer support team is available 24/7 to assist you throughout the process.",
  },
  {
    icon: <IconRefresh width={22} height={22} />,
    title: "Risk-Free Process",
    body: "Built to deliver real results. If no changes occur, every payment you've made will be fully refunded.",
  },
  {
    icon: <IconSpark width={22} height={22} />,
    title: "Trust & Transparency",
    body: "We stand by the effectiveness of our service, which is why we offer the best guarantee in the credit repair industry.",
  },
];

export default async function Social() {
  const rows = await getReviews();
  const list: ReviewCard[] = rows.length ? rows : FALLBACK;
  const stats = await getReviewStats();

  return (
    <>
      {/* ------------- Testimonials ------------- */}
      <section id="reviews" className="relative overflow-hidden bg-white py-20 lg:py-28">
        <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-line" />
        <div className="relative mx-auto max-w-[1450px] px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-[820px] text-center">
            <span className="inline-flex items-center gap-2 rounded-full border border-line bg-tint-soft px-3.5 py-1.5 text-[11px] font-semibold uppercase tracking-[0.14em] text-brand">
              <Stars value={5} size={13} />
              Testimonials
            </span>
            <h2 className="mt-5 text-[32px] font-extrabold leading-[1.08] tracking-[-1.4px] text-ink sm:text-[44px] lg:text-[52px]">
              Trusted by <span className="text-brand">thousands</span> of users
            </h2>

            <div className="mt-7 inline-flex flex-wrap items-center justify-center gap-x-5 gap-y-2 rounded-2xl border border-line bg-section px-7 py-4">
              <span className="text-[34px] font-extrabold leading-none tracking-[-1.6px] text-ink">
                {stats.avg}
              </span>
              <span className="text-left">
                <Stars value={5} size={16} />
                <span className="mt-1 block text-[12.5px] text-subtle">
                  {stats.count.toLocaleString()}+ reviews · Google &amp;
                  Trustpilot
                </span>
              </span>
            </div>
          </div>

          <div className="mt-14 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {list.slice(0, 8).map((r, i) => (
              <figure
                key={r.id}
                className={`anim-rise flex h-full flex-col justify-between rounded-[20px] border border-line bg-white p-7 transition-all duration-300 hover:-translate-y-1.5 hover:border-brand/35 hover:shadow-[0_36px_70px_-34px_rgba(41,93,236,0.5)] ${
                  i % 2 === 1 ? "sm:translate-y-5" : ""
                }`}
                style={{ animationDelay: `${i * 70}ms` }}
              >
                <div>
                  <Stars value={r.rating} />
                  <blockquote className="mt-5 text-[16.5px] leading-[1.55] font-medium tracking-[-0.35px] text-ink">
                    &ldquo;{r.quote}&rdquo;
                  </blockquote>
                </div>
                <figcaption className="mt-7 flex items-center gap-3">
                  <span className="inline-flex h-10 w-10 items-center justify-center rounded-full bg-brand text-[14px] font-bold text-white">
                    {r.author.slice(0, 1)}
                  </span>
                  <span>
                    <span className="block text-[14px] font-semibold tracking-[-0.2px] text-ink">
                      {r.author}
                    </span>
                    <span className="block text-[11.5px] text-mute">{r.tag}</span>
                  </span>
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      {/* ------------- Guarantee ------------- */}
      <section id="guarantee" className="relative overflow-hidden bg-night py-20 lg:py-28">
        <div className="pointer-events-none absolute inset-0 grid-dots opacity-[0.3]" />
        <div className="pointer-events-none absolute -right-32 top-0 h-[520px] w-[520px] rounded-full bg-[radial-gradient(closest-side,rgba(41,93,236,0.45),transparent)]" />

        <div className="relative mx-auto max-w-[1450px] px-4 sm:px-6 lg:px-8">
          <div className="grid items-center gap-12 lg:grid-cols-[0.85fr_1fr]">
            <div>
              <div className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-3.5 py-1.5 text-[11px] font-semibold uppercase tracking-[0.16em] text-brand-soft">
                <IconShield width={14} height={14} />
                Money-back guarantee like no other
              </div>

              <p className="mt-8 text-[86px] font-black leading-[0.82] tracking-[-5px] text-white sm:text-[120px] lg:text-[136px]">
                110
                <span className="text-brand-soft">%</span>
              </p>

              <h2 className="mt-6 max-w-[520px] text-[28px] font-extrabold leading-[1.12] tracking-[-1.2px] text-white sm:text-[36px]">
                We guarantee score improvement — or you get more than every
                penny back.
              </h2>

              <p className="mt-5 max-w-[520px] text-[16px] leading-[1.65] text-white/70">
                We believe in the quality of our products. If you&apos;re not
                satisfied, we will return{" "}
                <strong className="font-semibold text-white">110%</strong> (yes,
                110!) back of your money if KyKyDispute doesn&apos;t help you
                improve your credit after a year.
              </p>

              <a
                href="#faq"
                className="mt-7 inline-flex items-center gap-2 text-[15px] font-semibold text-brand-soft transition-colors hover:text-white"
              >
                View full terms
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M5 12h14M13 6l6 6-6 6" />
                </svg>
              </a>
            </div>

            <div className="grid gap-5 sm:grid-cols-2">
              {PILLARS.map((p) => (
                <article
                  key={p.title}
                  className="rounded-[20px] border border-white/10 bg-white/[0.045] p-7 transition-colors hover:border-brand/45 hover:bg-white/[0.07]"
                >
                  <span className="inline-flex h-11 w-11 items-center justify-center rounded-[14px] bg-brand/22 text-brand-soft">
                    {p.icon}
                  </span>
                  <h3 className="mt-5 text-[17px] font-bold leading-[1.25] tracking-[-0.5px] text-white">
                    {p.title}
                  </h3>
                  <p className="mt-3 text-[14px] leading-[1.6] text-white/62">
                    {p.body}
                  </p>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
