import { IconArrow, IconClock, SectionHead } from "@/components/Brand";
import { getPosts } from "@/lib/data";

const FALLBACK = [
  {
    id: 1,
    slug: "fcra-updates",
    category: "Credit Scores",
    title: "The New Rules of Credit Repair After the 2026 FCRA Updates",
    excerpt:
      "What the latest FCRA enforcement changes mean for how bureaus must investigate — and how to phrase a dispute that gets a real review.",
    image: "images/blog-2.png",
    readMins: 9,
    publishedAt: new Date("2026-01-14"),
  },
  {
    id: 2,
    slug: "kyky-dispute-faq",
    category: "Credit Monitoring",
    title: "KyKyDispute FAQ: Everything You Need To Know To Get The Best Results",
    excerpt:
      "Monitoring, attacks, Sprint Mail, IQ Action Plan — the answers that separate users who see movement from users who stall.",
    image: "images/blog-1.png",
    readMins: 12,
    publishedAt: new Date("2026-01-06"),
  },
  {
    id: 3,
    slug: "software-vs-services",
    category: "Credit Scores",
    title: "Credit Repair Software vs Credit Repair Services: What Lenders Care About",
    excerpt:
      "Lenders don't care who mailed the letter. They care about what's on your file. Here's how to judge any approach by the outcome.",
    image: "images/blog-3.png",
    readMins: 7,
    publishedAt: new Date("2025-12-19"),
  },
];

type PostCard = {
  id: number;
  slug: string;
  category: string;
  title: string;
  excerpt: string;
  image: string;
  readMins: number;
  publishedAt: Date;
};

export default async function Blog() {
  const rows = await getPosts();
  const posts: PostCard[] = rows.length ? rows : FALLBACK;

  return (
    <section id="guides" className="relative overflow-hidden bg-white py-20 lg:py-28">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-line" />
      <div className="relative mx-auto max-w-[1450px] px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col items-start justify-between gap-8 lg:flex-row lg:items-end">
          <SectionHead
            align="left"
            eyebrow="Credit Step-By-Step Guides"
            eyebrowIcon={<IconClock width={14} height={14} />}
            title={
              <>
                KyKyDispute AI helps you on your{" "}
                <span className="text-brand">financial journey</span>
              </>
            }
          />
          <a
            href="#guides"
            className="inline-flex items-center gap-2 rounded-full border border-line px-6 py-3.5 text-[14px] font-semibold tracking-[-0.2px] transition-colors hover:border-brand hover:text-brand"
          >
            View all guides
            <IconArrow width={17} height={17} />
          </a>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {posts.map((p, i) => (
            <article
              key={p.slug ?? p.id}
              className={`group flex flex-col overflow-hidden rounded-[22px] border border-line bg-white transition-all duration-300 hover:-translate-y-1.5 hover:shadow-[0_40px_80px_-42px_rgba(41,93,236,0.6)] ${
                i === 0 ? "lg:col-span-1" : ""
              }`}
            >
              <a href="#guides" className="relative block overflow-hidden">
                <img
                  src={p.image}
                  alt={p.title}
                  className="h-[220px] w-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-[linear-gradient(180deg,transparent_45%,rgba(11,18,40,0.35))]" />
                <span className="absolute left-4 top-4 rounded-full bg-white/92 px-3.5 py-1.5 text-[11px] font-bold uppercase tracking-[0.12em] text-brand">
                  {p.category}
                </span>
              </a>
              <div className="flex flex-1 flex-col p-7">
                <p className="inline-flex items-center gap-1.5 text-[11.5px] font-medium uppercase tracking-[0.12em] text-mute">
                  <IconClock width={13} height={13} />
                  {p.readMins} min read
                </p>
                <h3 className="mt-3 text-[20px] leading-[1.28] font-bold tracking-[-0.7px] text-ink">
                  <a href="#guides" className="transition-colors hover:text-brand">
                    {p.title}
                  </a>
                </h3>
                <p className="mt-3 text-[14.5px] leading-[1.65] text-subtle">
                  {p.excerpt}
                </p>
                <a
                  href="#guides"
                  className="mt-6 inline-flex items-center gap-1.5 text-[14px] font-semibold text-brand"
                >
                  Read more
                  <IconArrow width={16} height={16} className="transition-transform group-hover:translate-x-1" />
                </a>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
