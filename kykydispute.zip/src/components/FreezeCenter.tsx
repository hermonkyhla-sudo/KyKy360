"use client";

import { useEffect, useMemo, useState } from "react";
import {
  IconArrow,
  IconCheck,
  IconCopy,
  IconLock,
  IconRefresh,
  IconShield,
} from "@/components/Brand";
import {
  CRA_CATEGORIES,
  CRAS,
  FREEZE_COUNT,
  FREEZE_ESSENTIALS,
  craCategoryLabel,
  getCra,
  type Cra,
} from "@/lib/cras";

type FreezeResult = {
  letter: string;
  cra: { id: string; name: string; addr: string; phone: string; web: string };
};

const Snow = ({ size = 16 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" aria-hidden>
    <path d="M12 2v20M4 6l16 12M20 6L4 18M12 2l-2.5 3M12 2l2.5 3M12 22l-2.5-3M12 22l2.5-3M4 6l3.6.6M4 6l.6 3.6M20 18l-3.6-.6M20 18l-.6-3.6M20 6l-3.6.6M20 6l-.6 3.6M4 18l3.6-.6M4 18l.6-3.6" />
  </svg>
);

export default function FreezeCenter() {
  const [query, setQuery] = useState("");
  const [cat, setCat] = useState<string>("all");
  const [freezeOnly, setFreezeOnly] = useState(false);
  const [freezeFor, setFreezeFor] = useState<Cra | null>(null);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return CRAS.filter((c) => {
      if (cat !== "all" && c.cat !== cat) return false;
      if (freezeOnly && !c.freeze) return false;
      if (q && !`${c.name} ${c.blurb} ${craCategoryLabel(c.cat)}`.toLowerCase().includes(q))
        return false;
      return true;
    });
  }, [query, cat, freezeOnly]);

  function disputeWith(cra: Cra) {
    window.dispatchEvent(new CustomEvent("kyky:dispute", { detail: cra.id }));
    document
      .getElementById("lab")
      ?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  return (
    <section id="freeze" className="relative overflow-hidden bg-white py-20 lg:py-28">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-line" />
      <div className="pointer-events-none absolute -right-40 top-24 h-[460px] w-[460px] rounded-full bg-[radial-gradient(closest-side,rgba(41,93,236,0.14),transparent)]" />

      <div className="relative mx-auto max-w-[1450px] px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-[880px] text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-line bg-tint-soft px-3.5 py-1.5 text-[11px] font-semibold uppercase tracking-[0.14em] text-brand">
            <Snow size={14} />
            Freeze &amp; Dispute Center
          </span>
          <h2 className="mt-5 text-[32px] font-extrabold leading-[1.06] tracking-[-1.4px] text-ink sm:text-[44px] lg:text-[54px]">
            Every company with a file on you.{" "}
            <span className="text-brand">Freeze it. Dispute it.</span>
          </h2>
          <p className="mx-auto mt-5 max-w-[700px] text-[16px] leading-[1.6] text-subtle sm:text-[18px]">
            Under the FCRA, you can place a <strong className="text-ink">free security freeze</strong> and
            file a <strong className="text-ink">free dispute</strong> with every consumer reporting
            company — not just the big three. This is the full directory of{" "}
            {CRAS.length} reporting companies, straight from the federal list.
          </p>
        </div>

        {/* rights strip */}
        <div className="mx-auto mt-10 grid max-w-[1080px] gap-4 sm:grid-cols-3">
          {[
            {
              icon: <Snow size={18} />,
              t: "Free security freeze",
              d: "Blocks new accounts in your name. Free by law, and it never hurts your score.",
            },
            {
              icon: <IconShield width={18} height={18} />,
              t: "Free report every 12 months",
              d: "Every company below must give you your file free once a year — ask for it.",
            },
            {
              icon: <IconCheck width={18} height={18} />,
              t: "30-day investigations",
              d: "Dispute anything inaccurate and they must investigate, usually within 30 days.",
            },
          ].map((r) => (
            <div key={r.t} className="flex gap-3.5 rounded-2xl border border-line bg-section p-5">
              <span className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-white text-brand">
                {r.icon}
              </span>
              <div>
                <p className="text-[14.5px] font-bold tracking-[-0.3px] text-ink">{r.t}</p>
                <p className="mt-1 text-[12.5px] leading-[1.55] text-subtle">{r.d}</p>
              </div>
            </div>
          ))}
        </div>

        {/* essential freeze pass */}
        <div className="mt-10 overflow-hidden rounded-[24px] border border-brand/25 bg-gradient-to-br from-tint-soft via-white to-tint p-7 sm:p-9">
          <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
            <div className="max-w-[480px]">
              <p className="text-[11px] font-bold uppercase tracking-[0.16em] text-brand">
                Start here · The essential freeze pass
              </p>
              <p className="mt-2.5 text-[20px] leading-[1.3] font-bold tracking-[-0.6px] text-ink">
                Six freezes that lock down almost everything opened in your name
              </p>
              <p className="mt-2 text-[13.5px] leading-[1.6] text-subtle">
                Credit cards and loans, bank accounts, and new phone or utility
                service — frozen in one pass.
              </p>
            </div>
            <div className="flex flex-wrap gap-2.5">
              {FREEZE_ESSENTIALS.map((id) => {
                const c = getCra(id);
                return (
                  <button
                    key={id}
                    type="button"
                    onClick={() => setFreezeFor(c)}
                    className="inline-flex items-center gap-2 rounded-full border border-line bg-white px-4 py-2.5 text-[13px] font-semibold text-ink transition-all hover:-translate-y-[2px] hover:border-brand hover:text-brand"
                  >
                    <span className="text-brand">
                      <Snow size={14} />
                    </span>
                    {c.name.replace(/\s*\(.*\)\s*/, "")}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* toolbar */}
        <div className="mt-12 flex flex-col gap-4">
          <div className="flex flex-col gap-3 md:flex-row md:items-center">
            <label className="relative flex-1">
              <span className="sr-only">Search reporting companies</span>
              <svg className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-mute" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                <circle cx="11" cy="11" r="7" />
                <path d="m20 20-3.5-3.5" />
              </svg>
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search 64 companies — try “ChexSystems”, “tenant”, “LexisNexis”…"
                className="h-[52px] w-full rounded-full border border-line bg-white pl-12 pr-5 text-[15px] text-ink outline-none transition-colors placeholder:text-mute focus:border-brand"
              />
            </label>
            <button
              type="button"
              onClick={() => setFreezeOnly((v) => !v)}
              aria-pressed={freezeOnly}
              className={`inline-flex h-[52px] items-center justify-center gap-2 rounded-full border px-6 text-[14px] font-semibold transition-all ${
                freezeOnly
                  ? "border-brand bg-brand text-white"
                  : "border-line bg-white text-ink hover:border-brand hover:text-brand"
              }`}
            >
              <Snow size={16} />
              Freeze available ({FREEZE_COUNT})
            </button>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => setCat("all")}
              className={`rounded-full border px-4 py-2 text-[12.5px] font-semibold transition-all ${
                cat === "all"
                  ? "border-ink bg-ink text-white"
                  : "border-line bg-white text-subtle hover:border-brand hover:text-brand"
              }`}
            >
              All companies
            </button>
            {CRA_CATEGORIES.map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => setCat(c.id)}
                className={`rounded-full border px-4 py-2 text-[12.5px] font-semibold transition-all ${
                  cat === c.id
                    ? "border-ink bg-ink text-white"
                    : "border-line bg-white text-subtle hover:border-brand hover:text-brand"
                }`}
              >
                {c.label}
              </button>
            ))}
          </div>

          <p className="text-[13px] text-subtle" role="status">
            Showing <strong className="text-ink">{filtered.length}</strong> of{" "}
            {CRAS.length} consumer reporting companies
            {cat !== "all" &&
              ` in ${CRA_CATEGORIES.find((c) => c.id === cat)?.label}`}
            {freezeOnly && " that accept a security freeze"}.
          </p>
        </div>

        {/* directory grid */}
        {filtered.length ? (
          <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((c) => (
              <article
                key={c.id}
                className="group flex flex-col rounded-[20px] border border-line bg-white p-6 transition-all duration-300 hover:-translate-y-1 hover:border-brand/35 hover:shadow-[0_32px_64px_-34px_rgba(41,93,236,0.5)]"
              >
                <div className="flex items-start justify-between gap-3">
                  <h3 className="text-[16.5px] leading-[1.3] font-bold tracking-[-0.4px] text-ink">
                    {c.name}
                  </h3>
                  {c.freeze ? (
                    <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-tint px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.08em] text-brand">
                      <Snow size={11} />
                      Freeze
                    </span>
                  ) : (
                    <span className="shrink-0 rounded-full bg-section px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.08em] text-mute">
                      Report only
                    </span>
                  )}
                </div>

                <p className="mt-1.5 text-[11px] font-semibold uppercase tracking-[0.12em] text-brand">
                  {craCategoryLabel(c.cat)}
                </p>
                <p className="mt-2.5 line-clamp-3 text-[13.5px] leading-[1.6] text-subtle">
                  {c.blurb}
                </p>

                <div className="mt-4 space-y-1.5 border-t border-line pt-4 text-[12.5px] text-subtle">
                  {c.phone && (
                    <p>
                      <span className="font-semibold text-ink">Consumer line:</span>{" "}
                      {c.phone}
                    </p>
                  )}
                  <p className="leading-[1.5]">
                    <span className="font-semibold text-ink">By mail:</span>{" "}
                    {c.addr}
                  </p>
                </div>

                <div className="mt-5 flex gap-2 pt-1 mt-auto">
                  {c.freeze ? (
                    <button
                      type="button"
                      onClick={() => setFreezeFor(c)}
                      className="inline-flex h-10 flex-1 items-center justify-center gap-1.5 rounded-full bg-brand px-3 text-[12.5px] font-semibold text-white transition-all hover:bg-brand-700"
                    >
                      <Snow size={14} />
                      Freeze report
                    </button>
                  ) : (
                    <a
                      href={c.web}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex h-10 flex-1 items-center justify-center gap-1.5 rounded-full border border-line px-3 text-[12.5px] font-semibold text-ink transition-colors hover:border-brand hover:text-brand"
                    >
                      Free report
                      <IconArrow width={13} height={13} />
                    </a>
                  )}
                  <button
                    type="button"
                    onClick={() => disputeWith(c)}
                    className="inline-flex h-10 flex-1 items-center justify-center gap-1.5 rounded-full border border-line px-3 text-[12.5px] font-semibold text-ink transition-colors hover:border-brand hover:text-brand"
                  >
                    File dispute
                    <IconArrow width={13} height={13} />
                  </button>
                </div>
              </article>
            ))}
          </div>
        ) : (
          <div className="mt-6 rounded-[20px] border border-dashed border-line bg-section px-8 py-16 text-center">
            <p className="text-[17px] font-semibold text-ink">
              No company matches “{query}”
            </p>
            <p className="mx-auto mt-2 max-w-[420px] text-[14px] leading-[1.6] text-subtle">
              Try a category instead — or clear the search to browse the full
              federal directory of {CRAS.length} reporting companies.
            </p>
            <button
              type="button"
              onClick={() => {
                setQuery("");
                setCat("all");
                setFreezeOnly(false);
              }}
              className="mt-6 inline-flex h-11 items-center rounded-full bg-brand px-6 text-[14px] font-semibold text-white transition-colors hover:bg-brand-700"
            >
              Reset filters
            </button>
          </div>
        )}

        <p className="mx-auto mt-10 max-w-[860px] text-center text-[12px] leading-[1.7] text-mute">
          Directory source: CFPB “List of consumer reporting companies”
          (January 2025) — companies that have identified themselves as
          consumer reporting agencies as defined in the Fair Credit Reporting
          Act (FTC, May 2023). Contact details are each company&apos;s own
          published consumer contacts and have not been independently verified.
          A freeze must be confirmed by each company with identity
          verification; KyKyDispute prepares your request letters free.
        </p>
      </div>

      {freezeFor && (
        <FreezeModal cra={freezeFor} onClose={() => setFreezeFor(null)} />
      )}
    </section>
  );
}

/* ------------------------------------------------------------------ */

function FreezeModal({ cra, onClose }: { cra: Cra; onClose: () => void }) {
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<FreezeResult | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [onClose]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/freezes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fullName, email, cra: cra.id }),
      });
      const data = (await res.json()) as FreezeResult & { error?: string };
      if (!res.ok) throw new Error(data.error ?? "Something went wrong");
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  }

  async function copy() {
    if (!result) return;
    try {
      await navigator.clipboard.writeText(result.letter);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      setCopied(false);
    }
  }

  function download() {
    if (!result) return;
    const blob = new Blob([result.letter], {
      type: "text/plain;charset=utf-8",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `kyky-freeze-${cra.id}.txt`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  const input =
    "w-full rounded-xl border border-line bg-white px-4 py-3 text-[15px] text-ink outline-none transition-colors placeholder:text-mute focus:border-brand";
  const label =
    "block text-[11px] font-semibold uppercase tracking-[0.14em] text-subtle";

  return (
    <div
      className="fixed inset-0 z-[80] flex items-end justify-center bg-ink/55 p-0 backdrop-blur-sm sm:items-center sm:p-6"
      role="dialog"
      aria-modal="true"
      aria-label={`Freeze your report with ${cra.name}`}
      onClick={onClose}
    >
      <div
        className="anim-pop max-h-[92vh] w-full max-w-[640px] overflow-y-auto rounded-t-[24px] bg-white p-7 shadow-2xl sm:rounded-[24px] sm:p-9"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="inline-flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-[0.16em] text-brand">
              <Snow size={13} />
              Security freeze · free under the FCRA
            </p>
            <h3 className="mt-2 text-[24px] font-extrabold leading-[1.15] tracking-[-0.9px] text-ink">
              Freeze your report with {cra.name}
            </h3>
            <p className="mt-2 text-[13.5px] leading-[1.6] text-subtle">
              {craCategoryLabel(cra.cat)} · {cra.addr}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-line text-ink transition-colors hover:border-brand hover:text-brand"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
              <path d="M6 6l12 12M18 6L6 18" />
            </svg>
          </button>
        </div>

        {!result ? (
          <form onSubmit={submit} className="mt-7">
            <div className="space-y-4">
              <div>
                <label className={label} htmlFor="freeze-name">
                  Full name
                </label>
                <input
                  id="freeze-name"
                  required
                  className={`mt-2 ${input}`}
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Name as it appears on your report"
                />
              </div>
              <div>
                <label className={label} htmlFor="freeze-email">
                  Email for confirmation
                </label>
                <input
                  id="freeze-email"
                  type="email"
                  required
                  className={`mt-2 ${input}`}
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@email.com"
                />
              </div>
            </div>

            {error && (
              <p role="alert" className="mt-4 rounded-xl border border-[#9E1B32]/25 bg-[#FDEBEB] px-4 py-3 text-[13px] text-[#9E1B32]">
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={loading}
              className="mt-6 inline-flex h-[52px] w-full items-center justify-center gap-2 rounded-full bg-brand text-[15px] font-semibold text-white transition-all hover:bg-brand-700 disabled:opacity-60"
            >
              {loading ? (
                <>
                  <IconRefresh width={18} height={18} className="animate-spin" />
                  Preparing your freeze request…
                </>
              ) : (
                <>
                  <Snow size={17} />
                  Generate my freeze request
                </>
              )}
            </button>

            <p className="mt-4 flex items-start gap-2 text-[11.5px] leading-[1.55] text-mute">
              <IconLock width={14} height={14} className="mt-[1px] shrink-0" />
              KyKyDispute prepares the official request letter for you.
              {cra.name} confirms the freeze after verifying your identity —
              online, by phone ({cra.phone || "see their consumer site"}) or by
              mail. It&apos;s always free and never affects your score.
            </p>
          </form>
        ) : (
          <div className="mt-7">
            <div className="anim-pop rounded-2xl border border-good/30 bg-good/8 px-5 py-4">
              <p className="flex items-center gap-2 text-[15px] font-bold text-ink">
                <span className="inline-flex h-7 w-7 items-center justify-center rounded-full bg-good text-white">
                  <IconCheck width={15} height={15} />
                </span>
                Freeze request ready for {result.cra.name}
              </p>
              <p className="mt-2 text-[13px] leading-[1.6] text-subtle">
                Finish in whichever way suits you: complete it instantly on{" "}
                <a href={result.cra.web} target="_blank" rel="noopener noreferrer" className="font-semibold text-brand underline underline-offset-2">
                  their consumer site
                </a>
                {result.cra.phone ? (
                  <>
                    {" "}or by phone at{" "}
                    <strong className="text-ink">{result.cra.phone}</strong>
                  </>
                ) : null}
                , or mail the signed letter below to {result.cra.addr}.
              </p>
            </div>

            <div className="mt-5 overflow-hidden rounded-2xl border border-line">
              <div className="flex items-center justify-between border-b border-line bg-section px-4 py-2.5">
                <span className="text-[11px] font-semibold uppercase tracking-[0.12em] text-subtle">
                  freeze-{cra.id}.txt
                </span>
                <div className="flex gap-2">
                  <button type="button" onClick={copy} className="inline-flex items-center gap-1.5 rounded-full border border-line bg-white px-3 py-1.5 text-[11.5px] font-semibold text-ink transition-colors hover:border-brand hover:text-brand">
                    {copied ? <IconCheck width={12} height={12} /> : <IconCopy width={12} height={12} />}
                    {copied ? "Copied" : "Copy"}
                  </button>
                  <button type="button" onClick={download} className="inline-flex items-center gap-1.5 rounded-full bg-ink px-3 py-1.5 text-[11.5px] font-semibold text-white transition-colors hover:bg-brand">
                    <IconArrow width={12} height={12} />
                    Download
                  </button>
                </div>
              </div>
              <pre className="max-h-[320px] overflow-auto bg-white px-5 py-5 font-sans text-[12px] leading-[1.8] whitespace-pre-wrap text-ink/85">
                {result.letter}
              </pre>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="mt-6 inline-flex h-12 w-full items-center justify-center rounded-full border border-line text-[14px] font-semibold text-ink transition-colors hover:border-brand hover:text-brand"
            >
              Done
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
