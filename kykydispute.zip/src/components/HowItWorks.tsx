import {
  BureauChip,
  Button,
  IconArrow,
  IconChart,
  IconClock,
  IconFilter,
  IconMail,
  IconSpark,
  IconTrash,
  SectionHead,
} from "@/components/Brand";
import { ReviewPills } from "@/components/Hero";

const STEPS = [
  {
    icon: <IconSpark width={22} height={22} />,
    title: "AI Credit Analysis",
    body: "Our software scans your credit report for errors and negative items.",
  },
  {
    icon: <IconMail width={22} height={22} />,
    title: "Smart Dispute Letters",
    body: "AI generates legally-compliant dispute letters personalized to your situation.",
  },
  {
    icon: <IconFilter width={22} height={22} />,
    title: "Automated Mailing",
    body: "Letters sent via USPS through our mailing partner Sprint Mail. Track your order's progress online.",
  },
  {
    icon: <IconChart width={22} height={22} />,
    title: "Progress Tracking",
    body: "Monitor results across all 3 bureaus in real-time. Our IQ Action Plan highlights exactly what changed between reports so you always know what's working.",
  },
];

export default function HowItWorks() {
  return (
    <>
      {/* ---------------- How it works ---------------- */}
      <section id="how" className="relative overflow-hidden bg-white py-20 lg:py-28">
        <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-line" />
        <div className="relative mx-auto max-w-[1450px] px-4 sm:px-6 lg:px-8">
          <SectionHead
            eyebrow="How It Works"
            eyebrowIcon={<IconClock width={14} height={14} />}
            title={
              <>
                How KyKyDispute&apos;s AI{" "}
                <span className="text-brand">removes negative items</span>
              </>
            }
            sub="Traditional credit repair companies charge $250/month or more for basic dispute letters. Our AI credit repair software revolutionizes the process — it just takes a few minutes to get started."
          />

          <div className="mt-14 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {STEPS.map((s, i) => (
              <article
                key={s.title}
                className="group relative overflow-hidden rounded-[20px] border border-line bg-white p-7 transition-all duration-300 hover:-translate-y-1.5 hover:border-brand/35 hover:shadow-[0_36px_70px_-34px_rgba(41,93,236,0.55)]"
              >
                <span className="absolute right-5 top-4 text-[52px] font-black leading-none text-tint-soft select-none">
                  {i + 1}
                </span>
                <span className="relative inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-brand text-white shadow-[0_16px_30px_-16px_rgba(41,93,236,0.9)]">
                  {s.icon}
                </span>
                <h3 className="relative mt-6 text-[19px] font-bold leading-[1.25] tracking-[-0.6px] text-ink">
                  {s.title}
                </h3>
                <p className="relative mt-3 text-[14.5px] leading-[1.6] text-subtle">
                  {s.body}
                </p>
              </article>
            ))}
          </div>

          {/* price band */}
          <div className="mt-14 overflow-hidden rounded-[26px] border border-line bg-gradient-to-br from-tint-soft via-white to-tint p-8 sm:p-12">
            <div className="flex flex-col items-center gap-8 lg:flex-row lg:justify-between">
              <div className="max-w-[560px] text-center lg:text-left">
                <p className="text-[24px] leading-[1.25] font-bold tracking-[-0.8px] text-ink sm:text-[30px]">
                  Get the power of AI for your credit in your pocket for as low
                  as{" "}
                  <span className="text-brand">$49.99<span className="text-[16px]">/m</span></span>
                </p>
                <p className="mt-4 text-[13.5px] leading-[1.6] text-subtle">
                  3-Bureau credit monitoring required to use KyKyDispute&apos;s
                  AI features. Both VantageScore® and FICO® scores available.
                </p>
              </div>
              <div className="flex flex-wrap items-center justify-center gap-3">
                <BureauChip name="Equifax" />
                <BureauChip name="Experian" />
                <BureauChip name="TransUnion" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ---------------- FICO band ---------------- */}
      <section className="relative overflow-hidden bg-section py-20 lg:py-28">
        <div className="relative mx-auto max-w-[1450px] px-4 sm:px-6 lg:px-8">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <div className="relative order-2 lg:order-1">
              <div className="relative overflow-hidden rounded-[26px] border border-line">
                <img
                  src="images/fico-lifestyle.png"
                  alt="Woman holding a phone showing a FICO score of 752 inside the KyKyDispute app"
                  className="h-[380px] w-full object-cover object-center sm:h-[520px]"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-[linear-gradient(180deg,transparent_40%,rgba(11,18,40,0.55))]" />
                <div className="absolute bottom-6 left-6 right-6 rounded-2xl border border-white/25 bg-white/12 px-6 py-5 backdrop-blur-md">
                  <div className="flex items-end justify-between">
                    <div>
                      <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-white/70">
                        Your FICO® 8
                      </p>
                      <p className="mt-1 text-[42px] font-extrabold leading-none tracking-[-2px] text-white">
                        752
                      </p>
                    </div>
                    <div className="rounded-full bg-good px-3.5 py-1.5 text-[12px] font-semibold text-white">
                      +92 pts
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="order-1 lg:order-2">
              <SectionHead
                align="left"
                title={
                  <>
                    Your real <span className="text-brand">FICO® 8</span>{" "}
                    scores, inside KyKyDispute
                  </>
                }
                sub="Access the same scores 90% of lenders use — then let the AI prioritize the disputes that move them."
              />
              <ul className="mt-8 space-y-4">
                {[
                  "FICO® 8 from all 3 bureaus — the scores 90% of lenders use",
                  "Daily monitoring with zero credit impact",
                  "AI disputes prioritized by FICO® score impact",
                ].map((t) => (
                  <li key={t} className="flex items-start gap-3.5">
                    <span className="mt-[3px] inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-brand text-white">
                      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M20 6 9 17l-5-5" />
                      </svg>
                    </span>
                    <span className="text-[16.5px] leading-[1.55] tracking-[-0.3px] text-ink">
                      {t}
                    </span>
                  </li>
                ))}
              </ul>

              <div className="mt-9 flex flex-wrap items-center gap-4">
                <Button href="#get-started" size="lg">
                  Get your FICO® Score
                  <IconArrow width={18} height={18} />
                </Button>
                <Button href="#lab" variant="outline" size="lg">
                  <IconTrash width={17} height={17} />
                  Dispute a negative item
                </Button>
              </div>

              <div className="mt-9 rounded-2xl border border-line bg-white px-6 py-5">
                <ReviewPills />
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
