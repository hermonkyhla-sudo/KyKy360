import type { ReactNode, SVGProps } from "react";

/* ------------------------------------------------------------------ */
/*  The KyKyDispute mark — drawn as vector, not generated as an image */
/* ------------------------------------------------------------------ */

export function KyKyMark({
  size = 40,
  className = "",
}: {
  size?: number;
  className?: string;
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 48 48"
      fill="none"
      className={className}
      role="img"
      aria-label="KyKyDispute"
    >
      <defs>
        <linearGradient id="kyMarkBg" x1="6" y1="2" x2="42" y2="46">
          <stop offset="0" stopColor="#4A7BF7" />
          <stop offset="0.55" stopColor="#295DEC" />
          <stop offset="1" stopColor="#002896" />
        </linearGradient>
        <linearGradient id="kyMarkClaw" x1="10" y1="8" x2="38" y2="40">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="1" stopColor="#D6E2FF" />
        </linearGradient>
      </defs>
      {/* shield / claw-hide silhouette */}
      <path
        d="M24 1.6c3.4 2.2 7.7 3.5 12.4 3.5 3 0 5.6.7 7.4 1.9.9.6 1.4 1.5 1.4 2.6v13.7c0 9.6-5.5 17.9-13.7 22.2l-4.4 2.3a4.5 4.5 0 0 1-4.2 0l-4.4-2.3C10.3 41.2 4.8 32.9 4.8 23.3V9.6c0-1.1.5-2 1.4-2.6 1.8-1.2 4.4-1.9 7.4-1.9 4.7 0 9-1.3 12.4-3.5Z"
        fill="url(#kyMarkBg)"
      />
      <path
        d="M24 1.6c3.4 2.2 7.7 3.5 12.4 3.5 3 0 5.6.7 7.4 1.9.9.6 1.4 1.5 1.4 2.6v13.7c0 9.6-5.5 17.9-13.7 22.2l-4.4 2.3a4.5 4.5 0 0 1-4.2 0l-4.4-2.3C10.3 41.2 4.8 32.9 4.8 23.3V9.6c0-1.1.5-2 1.4-2.6 1.8-1.2 4.4-1.9 7.4-1.9 4.7 0 9-1.3 12.4-3.5Z"
        stroke="#ffffff"
        strokeOpacity="0.22"
        strokeWidth="1.2"
      />
      {/* three claw slashes */}
      <g fill="url(#kyMarkClaw)">
        <path d="M14.6 12.1c2.9 3.4 5.6 7.8 7.8 12.7-3.4-2.8-6.7-6.3-9.4-10.3a1.1 1.1 0 0 1 1.6-2.4Z" />
        <path d="M22.7 11.2c3.2 3.6 6.1 8.3 8.5 13.6-3.7-3-7.3-6.7-10.2-11a1.1 1.1 0 0 1 1.7-2.6Z" />
        <path d="M30.9 12.1c3 3.6 5.7 8.4 7.8 13.9-3.5-3-6.8-7-9.5-11.4a1.1 1.1 0 1 1 1.7-2.5Z" />
      </g>
      {/* jaw / beast grin */}
      <path
        d="M15.2 30.6c2.6 4.1 5.8 6.6 8.8 6.6s6.2-2.5 8.8-6.6c-2.8 1.6-5.7 2.4-8.8 2.4s-6-.8-8.8-2.4Z"
        fill="#ffffff"
        fillOpacity="0.92"
      />
    </svg>
  );
}

export function Wordmark({
  className = "",
  dark = false,
}: {
  className?: string;
  dark?: boolean;
}) {
  return (
    <span
      className={`inline-flex items-center gap-2.5 ${className}`}
      aria-label="KyKyDispute"
    >
      <KyKyMark size={34} />
      <span
        className={`text-[21px] leading-none tracking-[-0.9px] ${
          dark ? "text-white" : "text-ink"
        }`}
      >
        <span className="font-extrabold text-brand">KyKy</span>
        <span className="font-light">Dispute</span>
      </span>
    </span>
  );
}

/* ------------------------------------------------------------------ */
/*  Icons                                                              */
/* ------------------------------------------------------------------ */

type I = SVGProps<SVGSVGElement>;
const base = (p: I) => ({
  width: 20,
  height: 20,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.8,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
  ...p,
});

export const IconCheck = (p: I) => (
  <svg {...base(p)}>
    <path d="M20 6 9 17l-5-5" />
  </svg>
);
export const IconBolt = (p: I) => (
  <svg {...base(p)}>
    <path d="M13 2 4.5 13.5H11l-1 8.5 8.5-11.5H12l1-8.5Z" />
  </svg>
);
export const IconShield = (p: I) => (
  <svg {...base(p)}>
    <path d="M12 2.5 20 6v6c0 5-3.4 8.7-8 9.5-4.6-.8-8-4.5-8-9.5V6l8-3.5Z" />
    <path d="m9 12 2 2 4-4" />
  </svg>
);
export const IconSpark = (p: I) => (
  <svg {...base(p)}>
    <path d="M12 3v4M12 17v4M3 12h4M17 12h4M6.2 6.2 9 9M15 15l2.8 2.8M17.8 6.2 15 9M9 15l-2.8 2.8" />
  </svg>
);
export const IconMail = (p: I) => (
  <svg {...base(p)}>
    <rect x="2.5" y="5" width="19" height="14" rx="2.5" />
    <path d="m3.5 7 8.5 6 8.5-6" />
  </svg>
);
export const IconChart = (p: I) => (
  <svg {...base(p)}>
    <path d="M4 20V10M10 20V4M16 20v-7M22 20H2" />
  </svg>
);
export const IconFilter = (p: I) => (
  <svg {...base(p)}>
    <path d="M3 5h18l-7 8v6l-4 2v-8L3 5Z" />
  </svg>
);
export const IconLock = (p: I) => (
  <svg {...base(p)}>
    <rect x="4" y="10" width="16" height="11" rx="2.5" />
    <path d="M8 10V7a4 4 0 0 1 8 0v3" />
  </svg>
);
export const IconTrash = (p: I) => (
  <svg {...base(p)}>
    <path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v6M14 11v6" />
  </svg>
);
export const IconArrow = (p: I) => (
  <svg {...base(p)}>
    <path d="M5 12h14M13 6l6 6-6 6" />
  </svg>
);
export const IconChevron = (p: I) => (
  <svg {...base(p)}>
    <path d="m6 9 6 6 6-6" />
  </svg>
);
export const IconClock = (p: I) => (
  <svg {...base(p)}>
    <circle cx="12" cy="12" r="9" />
    <path d="M12 7v5l3.5 2" />
  </svg>
);
export const IconCopy = (p: I) => (
  <svg {...base(p)}>
    <rect x="9" y="9" width="12" height="12" rx="2.5" />
    <path d="M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1" />
  </svg>
);
export const IconRefresh = (p: I) => (
  <svg {...base(p)}>
    <path d="M20 11a8 8 0 1 0-1.2 5.2" />
    <path d="M20 5v6h-6" />
  </svg>
);
export const IconGlobe = (p: I) => (
  <svg {...base(p)}>
    <circle cx="12" cy="12" r="9" />
    <path d="M3 12h18M12 3c2.5 2.7 3.8 5.7 3.8 9S14.5 18.3 12 21c-2.5-2.7-3.8-5.7-3.8-9S9.5 5.7 12 3Z" />
  </svg>
);

/* ------------------------------------------------------------------ */
/*  Small primitives                                                   */
/* ------------------------------------------------------------------ */

export function Stars({
  value = 5,
  size = 15,
  color = "#00B67A",
}: {
  value?: number;
  size?: number;
  color?: string;
}) {
  return (
    <span
      className="inline-flex items-center gap-[3px]"
      aria-label={`${value} out of 5 stars`}
    >
      {[0, 1, 2, 3, 4].map((i) => (
        <svg
          key={i}
          width={size}
          height={size}
          viewBox="0 0 24 24"
          fill={i < value ? color : "#D6D6D6"}
          aria-hidden
        >
          <path d="m12 2 2.9 6.2 6.6.9-4.8 4.6 1.2 6.7L12 17.2 6.1 20.4l1.2-6.7L2.5 9.1l6.6-.9L12 2Z" />
        </svg>
      ))}
    </span>
  );
}

export function Eyebrow({
  children,
  icon,
  tone = "light",
}: {
  children: ReactNode;
  icon?: ReactNode;
  tone?: "light" | "dark";
}) {
  return (
    <span
      className={`inline-flex items-center gap-2 rounded-full border px-3.5 py-1.5 text-[11px] font-semibold uppercase tracking-[0.14em] ${
        tone === "dark"
          ? "border-white/15 bg-white/5 text-brand-soft"
          : "border-line bg-tint-soft text-brand"
      }`}
    >
      {icon}
      {children}
    </span>
  );
}

export function Button({
  children,
  href = "#get-started",
  variant = "primary",
  size = "md",
  className = "",
}: {
  children: ReactNode;
  href?: string;
  variant?: "primary" | "ghost" | "white" | "outline";
  size?: "sm" | "md" | "lg";
  className?: string;
}) {
  const sizes = {
    sm: "h-10 px-5 text-[14px]",
    md: "h-12 px-7 text-[15px]",
    lg: "h-[54px] px-9 text-[16px]",
  }[size];
  const variants = {
    primary:
      "bg-brand text-white shadow-[0_12px_26px_-12px_rgba(41,93,236,0.85)] hover:bg-brand-700",
    white: "bg-white text-brand hover:bg-tint",
    outline:
      "border border-line bg-white text-ink hover:border-brand hover:text-brand",
    ghost: "text-ink hover:text-brand",
  }[variant];
  return (
    <a
      href={href}
      className={`inline-flex items-center justify-center gap-2 rounded-full font-semibold tracking-[-0.2px] transition-all duration-200 hover:-translate-y-[2px] active:translate-y-0 ${sizes} ${variants} ${className}`}
    >
      {children}
    </a>
  );
}

export function SectionHead({
  eyebrow,
  eyebrowIcon,
  title,
  sub,
  align = "center",
  tone = "light",
  children,
}: {
  eyebrow?: string;
  eyebrowIcon?: ReactNode;
  title: ReactNode;
  sub?: ReactNode;
  align?: "center" | "left";
  tone?: "light" | "dark";
  children?: ReactNode;
}) {
  return (
    <div
      className={`${
        align === "center" ? "mx-auto max-w-[820px] text-center" : "max-w-[720px]"
      }`}
    >
      {eyebrow ? (
        <div className="mb-5 flex justify-center">
          <Eyebrow icon={eyebrowIcon} tone={tone}>
            {eyebrow}
          </Eyebrow>
        </div>
      ) : null}
      <h2
        className={`text-[32px] font-extrabold leading-[1.08] tracking-[-1.3px] sm:text-[42px] lg:text-[52px] ${
          tone === "dark" ? "text-white" : "text-ink"
        }`}
      >
        {title}
      </h2>
      {sub ? (
        <p
          className={`mt-5 text-[16px] leading-[1.6] sm:text-[18px] ${
            tone === "dark" ? "text-white/70" : "text-subtle"
          }`}
        >
          {sub}
        </p>
      ) : null}
      {children}
    </div>
  );
}

export function BureauChip({
  name,
  tone = "light",
}: {
  name: string;
  tone?: "light" | "dark";
}) {
  return (
    <span
      className={`inline-flex items-center gap-2 rounded-xl border px-4 py-2.5 text-[13px] font-semibold tracking-[-0.2px] ${
        tone === "dark"
          ? "border-white/12 bg-white/[0.06] text-white/85"
          : "border-line bg-white text-ink"
      }`}
    >
      <span
        className="h-2.5 w-2.5 rounded-full"
        style={{
          background:
            name === "Equifax"
              ? "#9E1B32"
              : name === "Experian"
                ? "#1d1d1f"
                : "#00a6ca",
        }}
      />
      {name}
    </span>
  );
}
