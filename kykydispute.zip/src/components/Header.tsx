"use client";

import { useEffect, useState } from "react";
import {
  IconBolt,
  IconChevron,
  IconGlobe,
  Wordmark,
} from "@/components/Brand";

type Item = { label: string; desc?: string; href: string; badge?: string };

const DROPS: Record<string, Item[]> = {
  Resources: [
    { label: "Blog", desc: "Credit tips & news", href: "#guides" },
    { label: "Credit Repair Guides", desc: "Step-by-step walkthroughs", href: "#guides" },
    { label: "Compare", desc: "vs. other credit apps", href: "#features" },
    { label: "Security & Privacy", desc: "How we protect your data", href: "#guarantee" },
  ],
  Training: [
    { label: "Learn the platform", desc: "Video walkthroughs", href: "#how" },
    { label: "iOS Widgets", desc: "Score at a glance", href: "#ios" },
    { label: "Getting Started", desc: "Full video tutorial", href: "#how" },
  ],
  Support: [
    { label: "Help & Support", desc: "FAQs & help docs", href: "#faq" },
    { label: "Money-Back Guarantee", desc: "Our commitment to you", href: "#guarantee" },
    { label: "Sprint Mail Support", desc: "Track your mailing", href: "#how" },
    { label: "KyKy Credit Monitoring", desc: "Partner support", href: "#pricing" },
  ],
};

const FLAT = [
  { label: "Pricing", href: "#pricing" },
  { label: "Reviews", href: "#reviews" },
  { label: "Freeze Center", href: "#freeze" },
  { label: "iOS App", href: "#ios" },
];

export default function Header() {
  const [open, setOpen] = useState<string | null>(null);
  const [mobile, setMobile] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 16);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = mobile ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [mobile]);

  return (
    <>
      {/* Announcement bar */}
      <a
        href="#pricing"
        className="block w-full bg-ink-2 px-4 py-[11px] text-center transition-colors hover:bg-[#2c2f40]"
      >
        <span className="mx-auto flex max-w-[900px] items-center justify-center gap-2.5 text-[13px] leading-[1.35] font-light tracking-[-0.3px] text-[#F1F1F1] sm:text-[14px]">
          <IconBolt width={18} height={18} className="shrink-0 text-brand-soft" />
          <span>
            <strong className="font-semibold text-white">New:</strong> Get your
            FICO® scores inside KyKyDispute – the same scores 90% of lenders
            use!
          </span>
          <IconChevron
            width={15}
            height={15}
            className="shrink-0 -rotate-90 text-white/50"
          />
        </span>
      </a>

      <header
        className={`sticky top-0 z-50 border-b bg-white/85 backdrop-blur-xl transition-all duration-300 ${
          scrolled
            ? "border-line shadow-[0_10px_30px_-24px_rgba(15,23,42,0.6)]"
            : "border-transparent"
        }`}
        onMouseLeave={() => setOpen(null)}
      >
        <div className="mx-auto flex h-[73px] max-w-[1450px] items-center justify-between gap-6 px-4 sm:px-6 lg:h-[81px] lg:px-8">
          <a href="#top" className="shrink-0">
            <Wordmark />
          </a>

          <nav className="hidden items-center gap-1 lg:flex">
            {FLAT.map((i) => (
              <a
                key={i.label}
                href={i.href}
                className="rounded-full px-4 py-2 text-[15px] font-medium tracking-[-0.2px] text-ink/80 transition-colors hover:bg-tint-soft hover:text-brand"
              >
                {i.label}
              </a>
            ))}
            {Object.keys(DROPS).map((key) => (
              <div key={key} className="relative">
                <button
                  type="button"
                  onMouseEnter={() => setOpen(key)}
                  onClick={() => setOpen(open === key ? null : key)}
                  aria-expanded={open === key}
                  className={`flex items-center gap-1.5 rounded-full px-4 py-2 text-[15px] font-medium tracking-[-0.2px] transition-colors ${
                    open === key
                      ? "bg-tint-soft text-brand"
                      : "text-ink/80 hover:bg-tint-soft hover:text-brand"
                  }`}
                >
                  {key}
                  <IconChevron
                    width={15}
                    height={15}
                    className={`transition-transform duration-200 ${
                      open === key ? "rotate-180" : ""
                    }`}
                  />
                </button>
                {open === key && (
                  <div className="anim-pop absolute left-1/2 top-[calc(100%+12px)] w-[300px] -translate-x-1/2 rounded-2xl border border-line bg-white p-2 shadow-[0_30px_60px_-24px_rgba(15,23,42,0.35)]">
                    {DROPS[key].map((d) => (
                      <a
                        key={d.label}
                        href={d.href}
                        onClick={() => setOpen(null)}
                        className="block rounded-xl px-4 py-3 transition-colors hover:bg-tint-soft"
                      >
                        <span className="block text-[14px] font-semibold tracking-[-0.2px] text-ink">
                          {d.label}
                        </span>
                        <span className="mt-0.5 block text-[12.5px] text-subtle">
                          {d.desc}
                        </span>
                      </a>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </nav>

          <div className="flex items-center gap-2 sm:gap-3">
            <button
              type="button"
              className="hidden items-center gap-1.5 rounded-full border border-line px-3 py-2 text-[13px] font-medium text-ink/70 transition-colors hover:border-brand hover:text-brand sm:inline-flex"
            >
              <IconGlobe width={15} height={15} />
              EN
              <span className="text-mute">/ ES</span>
            </button>
            <a
              href="#get-started"
              className="hidden text-[15px] font-semibold tracking-[-0.2px] text-ink/80 transition-colors hover:text-brand sm:inline"
            >
              Log In
            </a>
            <a
              href="#get-started"
              className="inline-flex h-11 items-center rounded-full bg-brand px-6 text-[14px] font-semibold text-white shadow-[0_12px_26px_-14px_rgba(41,93,236,0.9)] transition-all hover:-translate-y-[2px] hover:bg-brand-700"
            >
              Get Started
            </a>
            <button
              type="button"
              aria-label={mobile ? "Close menu" : "Open menu"}
              onClick={() => setMobile((v) => !v)}
              className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-line lg:hidden"
            >
              <span className="relative block h-[14px] w-[20px]">
                <span
                  className={`absolute left-0 h-[2px] w-full rounded bg-ink transition-all ${
                    mobile ? "top-[6px] rotate-45" : "top-0"
                  }`}
                />
                <span
                  className={`absolute top-[6px] left-0 h-[2px] w-full rounded bg-ink transition-all ${
                    mobile ? "opacity-0" : "opacity-100"
                  }`}
                />
                <span
                  className={`absolute left-0 h-[2px] w-full rounded bg-ink transition-all ${
                    mobile ? "top-[6px] -rotate-45" : "top-[12px]"
                  }`}
                />
              </span>
            </button>
          </div>
        </div>

        {mobile && (
          <div className="max-h-[calc(100vh-120px)] overflow-y-auto border-t border-line bg-white px-4 pb-8 pt-4 lg:hidden">
            {[...FLAT].map((i) => (
              <a
                key={i.label}
                href={i.href}
                onClick={() => setMobile(false)}
                className="block border-b border-line/70 py-3.5 text-[17px] font-semibold tracking-[-0.3px]"
              >
                {i.label}
              </a>
            ))}
            {Object.entries(DROPS).map(([key, items]) => (
              <div key={key} className="border-b border-line/70 py-3.5">
                <p className="text-[13px] font-semibold uppercase tracking-[0.12em] text-brand">
                  {key}
                </p>
                <div className="mt-2 space-y-2">
                  {items.map((d) => (
                    <a
                      key={d.label}
                      href={d.href}
                      onClick={() => setMobile(false)}
                      className="block text-[15px] text-ink/80"
                    >
                      {d.label}
                    </a>
                  ))}
                </div>
              </div>
            ))}
            <a
              href="#get-started"
              onClick={() => setMobile(false)}
              className="mt-5 flex h-12 items-center justify-center rounded-full bg-brand text-[15px] font-semibold text-white"
            >
              Get Started
            </a>
          </div>
        )}
      </header>
    </>
  );
}
