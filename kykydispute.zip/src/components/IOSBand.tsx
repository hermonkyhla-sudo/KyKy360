import {
  Button,
  IconArrow,
  IconBolt,
  IconCheck,
  IconShield,
  IconSpark,
} from "@/components/Brand";

export default function IOSBand() {
  return (
    <section id="ios" className="relative overflow-hidden bg-night py-20 lg:py-24">
      <div className="pointer-events-none absolute inset-0 grid-dots opacity-[0.35]" />
      <div className="pointer-events-none absolute -left-40 top-1/2 h-[560px] w-[560px] -translate-y-1/2 rounded-full bg-[radial-gradient(closest-side,rgba(41,93,236,0.45),transparent)]" />

      <div className="relative mx-auto max-w-[1450px] px-4 sm:px-6 lg:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-[1fr_0.85fr]">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-3.5 py-1.5 text-[11px] font-semibold uppercase tracking-[0.16em] text-white">
              <span className="rounded-full bg-brand px-2 py-[3px] text-[10px]">
                New
              </span>
              Now on iOS
            </div>

            <h2 className="mt-6 text-[34px] font-extrabold leading-[1.06] tracking-[-1.6px] text-white sm:text-[46px] lg:text-[56px]">
              Your credit future is now{" "}
              <span className="text-brand-soft">in your pocket</span>
            </h2>

            <p className="mt-6 max-w-[620px] text-[16px] leading-[1.65] text-white/70 sm:text-[18px]">
              The all-new KyKyDispute app is here. Join 100,000+ users
              analyzing their credit, finding negative items, and creating their
              next attack, with a private{" "}
              <strong className="font-semibold text-white">AI Credit Coach</strong>{" "}
              right on your iPhone. Free to download.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Button href="#get-started" variant="white" size="lg">
                Get The App
                <IconArrow width={18} height={18} />
              </Button>
              <Button href="#lab" variant="ghost" size="lg" className="text-white/80 hover:text-white">
                See what KyKyAI writes
              </Button>
            </div>

            <div className="mt-9 flex flex-wrap gap-x-7 gap-y-3 text-[13.5px] text-white/65">
              {[
                { icon: <IconCheck width={16} height={16} />, t: "iOS Widgets & Live Activities" },
                { icon: <IconShield width={16} height={16} />, t: "Private, on-device AI coach" },
                { icon: <IconBolt width={16} height={16} />, t: "Attack alerts in real time" },
              ].map((f) => (
                <span key={f.t} className="inline-flex items-center gap-2">
                  <span className="text-brand-soft">{f.icon}</span>
                  {f.t}
                </span>
              ))}
            </div>
          </div>

          <div className="relative mx-auto w-full max-w-[380px]">
            <div className="absolute inset-x-6 -bottom-6 top-10 rounded-[42px] bg-brand/25 blur-3xl" />
            <div className="anim-pop relative overflow-hidden rounded-[38px] border border-white/12 bg-white/[0.04] p-2">
              <img
                src="images/ios-phone.png"
                alt="KyKyDispute iOS app showing an AI credit score dashboard"
                className="h-[420px] w-full rounded-[32px] object-cover object-center sm:h-[520px]"
                loading="lazy"
              />
              <div className="pointer-events-none absolute inset-2 rounded-[32px] bg-[linear-gradient(180deg,rgba(255,255,255,0.12),transparent_38%,rgba(15,17,23,0.55))]" />
              <div className="absolute inset-x-5 bottom-5 rounded-2xl border border-white/20 bg-white/10 px-5 py-4 backdrop-blur-md">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-[11px] uppercase tracking-[0.14em] text-white/60">
                      FICO® 8 · Experian
                    </p>
                    <p className="mt-1 text-[30px] font-extrabold leading-none tracking-[-1.4px] text-white">
                      752
                    </p>
                  </div>
                  <div className="rounded-full bg-good/20 px-3 py-1.5 text-[12px] font-semibold text-[#5BE3B4]">
                    +92 this year
                  </div>
                </div>
                <div className="mt-3 flex h-[42px] items-end gap-1">
                  {[30, 42, 38, 52, 60, 58, 72, 88].map((h, i) => (
                    <span
                      key={i}
                      className="flex-1 rounded-[3px] bg-white/45"
                      style={{ height: `${h}%` }}
                    />
                  ))}
                </div>
              </div>
            </div>
            <div className="absolute -left-4 top-10 hidden rounded-2xl border border-white/12 bg-white/10 px-4 py-3 backdrop-blur-md sm:block">
              <p className="inline-flex items-center gap-2 text-[12px] font-semibold text-white">
                <IconSpark width={15} height={15} className="text-brand-soft" />
                3 new items flagged
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
