import {
  IconCheck,
  IconGlobe,
  IconLock,
  IconShield,
  Stars,
  Wordmark,
} from "@/components/Brand";

const COLUMNS: { title: string; links: { label: string; href: string; badge?: string }[] }[] = [
  {
    title: "App Links",
    links: [
      { label: "Log In", href: "#get-started" },
      { label: "Sign Up", href: "#get-started" },
      { label: "Help & Support", href: "#faq" },
      { label: "Training", href: "#how" },
      { label: "iOS App", href: "#ios", badge: "New" },
      { label: "iOS Widgets", href: "#ios", badge: "New" },
    ],
  },
  {
    title: "Helpful Links",
    links: [
      { label: "Pricing | How It Works", href: "#pricing" },
      { label: "How It Works", href: "#how" },
      { label: "Freeze & Dispute Center", href: "#freeze" },
      { label: "Reviews", href: "#reviews" },
      { label: "110% Money-Back Guarantee", href: "#guarantee" },
      { label: "Blog", href: "#guides" },
      { label: "FICO® FAQs", href: "#faq" },
    ],
  },
  {
    title: "Compare",
    links: [
      { label: "Compare KyKyDispute to other apps", href: "#features" },
      { label: "KyKyDispute vs Credit Repair Services", href: "#features" },
      { label: "KyKyDispute vs DIY Letters", href: "#lab" },
    ],
  },
  {
    title: "Partner Support",
    links: [
      { label: "KyKy Credit Monitoring Support", href: "#faq" },
      { label: "Pro Credit Watch Support", href: "#faq" },
      { label: "Sprint Mail Support", href: "#faq" },
    ],
  },
  {
    title: "Getting Started",
    links: [
      { label: "How to use KyKyDispute (full video tutorial)", href: "#how" },
      { label: "Create your first attack", href: "#lab" },
      { label: "Understanding your 3-bureau report", href: "#how" },
    ],
  },
];

const FOOTNOTES = [
  "Average credit score increase of +46 points based on a sample of 8,482 KyKyDispute users across all usage periods.",
  "Average increase of +56 points observed within 90 days, based on a sample of 2,141 users.",
  "Average increase of +66 points observed after 6 or more months of active use, based on a sample of 258 users.",
  "Users with a starting score of 600 or below experienced an average increase of +61 points, based on a sample of 5,267 users.",
  "KyKyDispute users have collectively gained approximately 389,000 credit score points across all tracked accounts as of late 2025.",
];

export default function Footer() {
  return (
    <footer id="faq" className="relative overflow-hidden bg-night pt-20">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-white/10" />
      <div className="pointer-events-none absolute left-1/2 top-0 h-[380px] w-[900px] -translate-x-1/2 rounded-full bg-[radial-gradient(closest-side,rgba(41,93,236,0.28),transparent)]" />

      <div className="relative mx-auto max-w-[1450px] px-4 sm:px-6 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-[0.9fr_2fr]">
          <div>
            <Wordmark dark />
            <p className="mt-6 max-w-[380px] text-[15px] leading-[1.7] text-white/62">
              Your DIY credit repair dispute assistant, powered by AI. Dispute
              negative items, mail real letters, and track every point of
              progress across all three bureaus.
            </p>

            <div className="mt-8 space-y-4">
              <div className="flex items-start gap-3">
                <Stars value={5} size={15} />
                <div>
                  <p className="text-[13.5px] font-semibold text-white">
                    Trusted by thousands
                  </p>
                  <p className="text-[12px] text-white/55">
                    Rated 4.8 stars by 4,000+ users
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <IconLock width={18} height={18} className="mt-[2px] text-brand-soft" />
                <div>
                  <p className="text-[13.5px] font-semibold text-white">
                    Your security is our priority
                  </p>
                  <p className="text-[12px] text-white/55">
                    Bank-grade encryption, 24/7 support
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-8 inline-flex items-center gap-2 rounded-full border border-white/12 px-4 py-2.5 text-[12.5px] text-white/70">
              <IconGlobe width={15} height={15} />
              English · Español
            </div>
          </div>

          <div className="grid grid-cols-2 gap-x-8 gap-y-10 sm:grid-cols-3 lg:grid-cols-5">
            {COLUMNS.map((col) => (
              <nav key={col.title} aria-label={col.title}>
                <h3 className="text-[11px] font-bold uppercase tracking-[0.18em] text-brand-soft">
                  {col.title}
                </h3>
                <ul className="mt-5 space-y-3">
                  {col.links.map((l) => (
                    <li key={l.label}>
                      <a
                        href={l.href}
                        className="inline-flex items-start gap-2 text-[13.5px] leading-[1.5] text-white/62 transition-colors hover:text-white"
                      >
                        {l.label}
                        {l.badge && (
                          <span className="mt-[2px] rounded-full bg-brand px-2 py-[1px] text-[9px] font-bold uppercase tracking-[0.1em] text-white">
                            {l.badge}
                          </span>
                        )}
                      </a>
                    </li>
                  ))}
                </ul>
              </nav>
            ))}
          </div>
        </div>

        {/* disclosures */}
        <div className="mt-16 rounded-[22px] border border-white/10 bg-white/[0.035] p-8">
          <div className="flex items-start gap-4">
            <span className="mt-[2px] inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-brand/22 text-brand-soft">
              <IconShield width={20} height={20} />
            </span>
            <div>
              <p className="max-w-[900px] text-[13.5px] leading-[1.75] text-white/62">
                Making your dispute letters with KyKyDispute&apos;s engine is
                completely free. But, you need an active 3-bureau monitoring
                subscription powered by KyKy Credit Monitoring or Pro Credit
                Watch to do it. It&apos;s starting at $49.99 a month. If you have
                3 Bureau Monitoring, you can generate as many letters as you
                want or need on your attacks inside of KyKyDispute. Learn more
                in the{" "}
                <a href="#pricing" className="font-semibold text-brand-soft underline underline-offset-4">
                  Pricing
                </a>{" "}
                page.
              </p>
              <p className="mt-4 text-[13px] leading-[1.75] text-white/55">
                Results vary. Individual outcomes depend on credit profile,
                bureau response, and user participation. Not everyone will
                achieve the same results.
              </p>

              <ol className="mt-5 space-y-2">
                {FOOTNOTES.map((f, i) => (
                  <li
                    key={f}
                    className="flex gap-2.5 text-[11.5px] leading-[1.6] text-white/45"
                  >
                    <span className="shrink-0 text-brand-soft">{i + 1}</span>
                    {f}
                  </li>
                ))}
              </ol>

              <a
                href="#guarantee"
                className="mt-5 inline-flex items-center gap-2 text-[12.5px] font-semibold text-brand-soft transition-colors hover:text-white"
              >
                View full disclosures
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M5 12h14M13 6l6 6-6 6" />
                </svg>
              </a>
            </div>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-5 border-t border-white/10 py-8 sm:flex-row">
          <p className="text-[12.5px] text-white/50">
            © 2026 KyKyDispute LLC. All rights reserved.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2">
            {["Security", "Privacy Policy", "Terms of Service", "Disclosures"].map(
              (l) => (
                <a
                  key={l}
                  href="#faq"
                  className="text-[12.5px] text-white/55 transition-colors hover:text-white"
                >
                  {l}
                </a>
              ),
            )}
          </div>
          <p className="inline-flex items-center gap-2 text-[12.5px] text-white/50">
            <IconCheck width={14} height={14} className="text-brand-soft" />
            Designed and built in the USA
          </p>
        </div>
      </div>
    </footer>
  );
}
