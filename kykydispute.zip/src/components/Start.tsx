import {
  Button,
  IconArrow,
  IconChart,
  IconCheck,
  IconClock,
  IconMail,
  IconSpark,
  IconTrash,
  SectionHead,
} from "@/components/Brand";
import LeadForm from "@/components/LeadForm";

const STEPS = [
  {
    tag: "Step 1",
    title: "Sign up for monitoring & get your free KyKyDispute account",
    body: "All you need is active credit monitoring, the rest is on us. Choose KyKy Credit Monitoring ($49.99/mo, VantageScore) or ProCreditWatch ($59.99/mo, FICO 8) for advanced 3-bureau reports on your credit, so you can have a better idea of your financial status.",
    icon: <IconSpark width={22} height={22} />,
  },
  {
    tag: "Step 2",
    title: "Get your full credit report & get clarity on what is affecting you",
    body: "Get access to your full credit report from all 3 bureaus, understand in full detail what is hurting and affecting your credit score. It's time to address what has been stopping you from reaching your goals.",
    icon: <IconChart width={22} height={22} />,
  },
  {
    tag: "Step 3",
    title: "Attack using our AI disputing engine — it'll do it all for you!",
    body: "Our proprietary KyKyAI engine has processed close to a million letters to dispute erroneous items on consumers' accounts. Take a full in-depth view into your credit report using our smart filter, and start your first Attack to get rid of any erroneous items on your report.",
    icon: <IconTrash width={22} height={22} />,
  },
  {
    tag: "Step 4",
    title: "Mail your attack",
    body: "You've created your attack. Now it's time to mail it out. Choose your path: Sprint Mail (paid) — one click, everything handled: printing, packaging, mailing, even tracking, sent via 1st Class. Or Free Download (DIY) — print at home, stuff, stamp and head to the post office. The faster your letters go out, the faster credit bureaus must respond.",
    icon: <IconMail width={22} height={22} />,
  },
];

const INCLUDED = [
  "AI-powered dispute letter generation",
  "3-bureau credit monitoring",
  "Automated mailing service",
  "Progress tracking dashboard",
  "110% money-back guarantee",
];

export default function Start() {
  return (
    <>
      {/* ------------- 5 minute process ------------- */}
      <section id="get-started" className="relative overflow-hidden bg-white py-20 lg:py-28">
        <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-line" />
        <div className="relative mx-auto max-w-[1450px] px-4 sm:px-6 lg:px-8">
          <SectionHead
            eyebrow="How it works"
            eyebrowIcon={<IconClock width={14} height={14} />}
            title={
              <>
                Start your DIY process in just{" "}
                <span className="text-brand">5 minutes</span>, powered by AI
              </>
            }
            sub="When you're enrolled with KyKy Credit Monitoring or ProCreditWatch, using KyKyDispute is entirely free for dispute letters. We're offering an entirely new & automated AI credit disputing solution to improve your scores."
          />

          <div className="relative mt-14 grid gap-6 lg:grid-cols-2">
            <div className="pointer-events-none absolute inset-x-[calc(50%-1px)] top-8 hidden w-px bg-gradient-to-b from-transparent via-line to-transparent lg:block" />
            {STEPS.map((s, i) => (
              <article
                key={s.tag}
                className="relative rounded-[22px] border border-line bg-section p-8 transition-all duration-300 hover:-translate-y-1 hover:border-brand/35 hover:bg-white hover:shadow-[0_36px_70px_-38px_rgba(41,93,236,0.55)]"
              >
                <div className="flex items-center gap-4">
                  <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-brand text-white">
                    {s.icon}
                  </span>
                  <span className="text-[11px] font-bold uppercase tracking-[0.18em] text-brand">
                    {s.tag}
                  </span>
                </div>
                <h3 className="mt-6 text-[21px] leading-[1.25] font-bold tracking-[-0.7px] text-ink">
                  {s.title}
                </h3>
                <p className="mt-4 text-[15px] leading-[1.7] text-subtle">
                  {s.body}
                </p>
                {i === 3 && (
                  <div className="mt-6 grid gap-3 sm:grid-cols-2">
                    <div className="rounded-xl border border-line bg-white p-4">
                      <p className="text-[13px] font-semibold text-ink">
                        Sprint Mail
                        <span className="ml-2 rounded-full bg-tint px-2 py-[2px] text-[10px] font-bold uppercase tracking-[0.1em] text-brand">
                          Paid
                        </span>
                      </p>
                      <p className="mt-1.5 text-[12.5px] leading-[1.55] text-subtle">
                        One click. Printing, packaging, mailing and tracking all
                        handled.
                      </p>
                    </div>
                    <div className="rounded-xl border border-line bg-white p-4">
                      <p className="text-[13px] font-semibold text-ink">
                        Free Download
                        <span className="ml-2 rounded-full bg-good/12 px-2 py-[2px] text-[10px] font-bold uppercase tracking-[0.1em] text-good">
                          DIY
                        </span>
                      </p>
                      <p className="mt-1.5 text-[12.5px] leading-[1.55] text-subtle">
                        Download, print at home, stuff, stamp and mail it
                        yourself.
                      </p>
                    </div>
                  </div>
                )}
              </article>
            ))}
          </div>

          <div className="mt-12 text-center">
            <Button href="#pricing" size="lg">
              Get Started
              <IconArrow width={18} height={18} />
            </Button>
          </div>
        </div>
      </section>

      {/* ------------- Pricing / get started ------------- */}
      <section id="pricing" className="relative overflow-hidden bg-section py-20 lg:py-28">
        <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-line" />
        <div className="pointer-events-none absolute left-1/2 top-0 h-[520px] w-[1000px] -translate-x-1/2 rounded-full bg-[radial-gradient(closest-side,rgba(41,93,236,0.16),transparent)]" />

        <div className="relative mx-auto max-w-[1450px] px-4 sm:px-6 lg:px-8">
          <div className="grid items-start gap-12 lg:grid-cols-[1.1fr_0.9fr]">
            <div>
              <SectionHead
                align="left"
                eyebrow="Get Started Today"
                eyebrowIcon={<IconCheck width={14} height={14} />}
                title={
                  <>
                    Proven results — or{" "}
                    <span className="text-brand">more than your money back</span>
                  </>
                }
                sub="No risk, all reward. Take the first step towards a better financial future today. You deserve financial freedom because you're more than a credit score, and KyKyDispute is here to help you achieve it."
              />

              <div className="mt-9 rounded-[22px] border border-line bg-white p-8">
                <div className="flex flex-wrap items-end justify-between gap-5 border-b border-line pb-6">
                  <div>
                    <p className="text-[13px] font-semibold uppercase tracking-[0.16em] text-brand">
                      KyKyDispute
                    </p>
                    <p className="mt-2 text-[42px] font-extrabold leading-none tracking-[-2px] text-ink">
                      Free
                    </p>
                    <p className="mt-3 max-w-[380px] text-[13px] leading-[1.6] text-subtle">
                      AI dispute features require a separate credit monitoring
                      subscription (KyKy Credit Monitoring or ProCreditWatch),
                      from $49.99/month.
                    </p>
                  </div>
                  <Button href="#get-started" size="lg">
                    Get Started
                    <IconArrow width={18} height={18} />
                  </Button>
                </div>

                <div className="mt-6 grid gap-3 sm:grid-cols-2">
                  {[
                    { n: "KyKy Credit Monitoring", p: "$49.99/mo", s: "VantageScore® 3-bureau" },
                    { n: "ProCreditWatch", p: "$59.99/mo", s: "FICO® 8 3-bureau" },
                  ].map((m) => (
                    <div
                      key={m.n}
                      className="rounded-2xl border border-line bg-section p-5 transition-colors hover:border-brand/40"
                    >
                      <p className="text-[15px] font-bold tracking-[-0.4px] text-ink">
                        {m.n}
                      </p>
                      <p className="mt-1 text-[12.5px] text-subtle">{m.s}</p>
                      <p className="mt-3 text-[22px] font-extrabold tracking-[-1px] text-brand">
                        {m.p}
                      </p>
                    </div>
                  ))}
                </div>

                <ul className="mt-7 grid gap-3">
                  {INCLUDED.map((f) => (
                    <li key={f} className="flex items-center gap-3">
                      <span className="inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-brand text-white">
                        <IconCheck width={13} height={13} />
                      </span>
                      <span className="text-[15px] tracking-[-0.3px] text-ink">
                        {f}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="lg:sticky lg:top-[110px]">
              <LeadForm />
              <div className="mt-6 rounded-[22px] border border-line bg-white p-7">
                <div className="flex items-center gap-4">
                  <span className="text-[38px] font-extrabold leading-none tracking-[-1.8px] text-ink">
                    4.8
                  </span>
                  <div>
                    <div className="flex items-center gap-1 text-[#00B67A]">
                      {"★★★★★".split("").map((s, i) => (
                        <span key={i} className="text-[16px]">
                          {s}
                        </span>
                      ))}
                    </div>
                    <p className="mt-1 text-[12.5px] text-subtle">
                      Rated 4.8 stars by 4,000+ users
                    </p>
                  </div>
                </div>
                <p className="mt-5 border-t border-line pt-5 text-[13px] leading-[1.65] text-subtle">
                  4.4 out of 5 based on 1,861 Trustpilot reviews. Results vary.
                  Individual outcomes depend on credit profile, bureau response
                  and user participation.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ------------- FICO CTA ------------- */}
      <section className="relative overflow-hidden bg-brand py-16 lg:py-20">
        <div className="pointer-events-none absolute inset-0 grid-dots opacity-[0.25]" />
        <div className="pointer-events-none absolute -left-24 top-1/2 h-[420px] w-[420px] -translate-y-1/2 rounded-full bg-[radial-gradient(closest-side,rgba(255,255,255,0.28),transparent)]" />
        <div className="relative mx-auto max-w-[1450px] px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col items-center gap-9 lg:flex-row lg:justify-between">
            <div className="max-w-[760px] text-center lg:text-left">
              <h2 className="text-[30px] font-extrabold leading-[1.1] tracking-[-1.3px] text-white sm:text-[42px]">
                Get lender-used FICO® scores now inside of KyKyDispute
              </h2>
              <p className="mt-5 text-[16px] leading-[1.65] text-white/82 sm:text-[18px]">
                Access the same FICO® 8 scores that 90% of lenders use for
                credit decisions. Monitor your real credit health while Dispute
                KyKyDispute&apos;s AI works to improve what matters most. Get
                started
                and choose between Vantage or FICO® today.
              </p>
            </div>
            <div className="flex shrink-0 flex-col items-center gap-3">
              <Button href="#get-started" variant="white" size="lg">
                Get Started
                <IconArrow width={18} height={18} />
              </Button>
              <span className="text-[12px] text-white/70">
                110% money-back guarantee
              </span>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
