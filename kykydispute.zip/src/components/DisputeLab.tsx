"use client";

import { useEffect, useMemo, useState } from "react";
import {
  IconArrow,
  IconBolt,
  IconCheck,
  IconCopy,
  IconRefresh,
  IconSpark,
} from "@/components/Brand";
import { CRA_CATEGORIES, CRAS, craCategoryLabel, getCra } from "@/lib/cras";

const QUICK = [
  "equifax",
  "experian",
  "transunion",
  "innovis",
  "chex-systems-inc",
];

const CATEGORIES = [
  { id: "collections", label: "Collections" },
  { id: "charge-off", label: "Charge-off" },
  { id: "late-payments", label: "Late Payments" },
  { id: "inquiries", label: "Credit Inquiries" },
  { id: "public-records", label: "Public Records" },
  { id: "personal-data", label: "Personal Data" },
];

type Result = {
  letter: string;
  impact: { score: string; odds: string };
  id: number | null;
};

export default function DisputeLab() {
  const [fullName, setFullName] = useState("Jordan A. Rivera");
  const [cra, setCra] = useState("experian");
  const [category, setCategory] = useState("collections");
  const [creditor, setcreditor] = useState("Midland Funding LLC");
  const [accountRef, setAccountRef] = useState("4821");
  const [note, setNote] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<Result | null>(null);
  const [copied, setCopied] = useState(false);

  const company = getCra(cra);

  // The Freeze & Dispute Center hands a company over to the lab.
  useEffect(() => {
    const onPick = (e: Event) => {
      const id = (e as CustomEvent<string>).detail;
      if (id) setCra(id);
    };
    window.addEventListener("kyky:dispute", onPick);
    return () => window.removeEventListener("kyky:dispute", onPick);
  }, []);

  const canSubmit = useMemo(
    () => fullName.trim().length > 2 && !loading,
    [fullName, loading],
  );

  async function generate(e: React.FormEvent) {
    e.preventDefault();
    if (!canSubmit) return;
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/disputes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fullName, cra, category, creditor, accountRef, note }),
      });
      const data = (await res.json()) as Result & { error?: string };
      if (!res.ok) throw new Error(data.error ?? "Something went wrong");
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  }

  async function copy() {
    if (!result) return;
    try {
      await navigator.clipboard.writeText(result.letter);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      setCopied(false);
    }
  }

  function download() {
    if (!result) return;
    const blob = new Blob([result.letter], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `kyky-dispute-${cra}-${category}.txt`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  const field =
    "w-full rounded-xl border border-line bg-white px-4 py-3 text-[15px] text-ink outline-none transition-colors placeholder:text-mute focus:border-brand";
  const label =
    "block text-[11px] font-semibold uppercase tracking-[0.14em] text-subtle";

  return (
    <section id="lab" className="relative overflow-hidden bg-section py-20 lg:py-28">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-line" />
      <div className="pointer-events-none absolute -left-40 top-20 h-[480px] w-[480px] rounded-full bg-[radial-gradient(closest-side,rgba(41,93,236,0.18),transparent)]" />

      <div className="relative mx-auto max-w-[1450px] px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-[880px] text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-brand/25 bg-white px-3.5 py-1.5 text-[11px] font-semibold uppercase tracking-[0.14em] text-brand">
            <IconBolt width={14} height={14} />
            KyKyAI · live demo
          </span>
          <h2 className="mt-5 text-[32px] font-extrabold leading-[1.06] tracking-[-1.4px] text-ink sm:text-[44px] lg:text-[54px]">
            Build an <span className="text-brand">attack</span> in seconds
          </h2>
          <p className="mx-auto mt-5 max-w-[640px] text-[16px] leading-[1.6] text-subtle sm:text-[18px]">
            Pick any of the {64} consumer reporting companies, choose the
            negative item, and watch KyKyAI write a legally-grounded dispute
            letter — the same engine that has processed close to a million
            letters.
          </p>
        </div>

        <div className="mt-12 grid gap-6 lg:grid-cols-[minmax(0,420px)_minmax(0,1fr)]">
          {/* ---- form ---- */}
          <form
            onSubmit={generate}
            className="rounded-[22px] border border-line bg-white p-7 shadow-[0_30px_70px_-40px_rgba(15,23,42,0.4)]"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-[18px] font-bold tracking-[-0.6px] text-ink">
                Attack builder
              </h3>
              <span className="inline-flex items-center gap-1.5 rounded-full bg-tint-soft px-3 py-1.5 text-[11px] font-semibold text-brand">
                <IconSpark width={13} height={13} />
                AI ready
              </span>
            </div>

            <div className="mt-6 space-y-5">
              <div>
                <label className={label} htmlFor="lab-name">
                  Full name
                </label>
                <input
                  id="lab-name"
                  className={`mt-2 ${field}`}
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Name as it appears on your report"
                />
              </div>

              <div>
                <span className={label}>Consumer reporting company</span>
                <div className="mt-2 flex flex-wrap gap-2">
                  {QUICK.map((id) => {
                    const c = getCra(id);
                    return (
                      <button
                        key={id}
                        type="button"
                        onClick={() => setCra(id)}
                        className={`rounded-full border px-3.5 py-2 text-[12.5px] font-semibold transition-all ${
                          cra === id
                            ? "border-brand bg-brand text-white shadow-[0_12px_24px_-14px_rgba(41,93,236,0.9)]"
                            : "border-line bg-white text-ink/70 hover:border-brand/50 hover:text-brand"
                        }`}
                      >
                        {c.name.replace(/\s*\(.*\)\s*/, "")}
                      </button>
                    );
                  })}
                </div>
                <select
                  aria-label="All consumer reporting companies"
                  className={`mt-3 ${field}`}
                  value={cra}
                  onChange={(e) => setCra(e.target.value)}
                >
                  {CRA_CATEGORIES.map((cat) => (
                    <optgroup key={cat.id} label={cat.label}>
                      {CRAS.filter((c) => c.cat === cat.id).map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.name}
                        </option>
                      ))}
                    </optgroup>
                  ))}
                </select>
                <p className="mt-2.5 flex flex-wrap items-center gap-x-2 gap-y-1 text-[12px] leading-[1.5] text-subtle">
                  <span className="font-semibold text-ink">
                    {craCategoryLabel(company.cat)}
                  </span>
                  <span aria-hidden>·</span>
                  <span>{company.addr}</span>
                  {company.freeze && (
                    <span className="rounded-full bg-good/12 px-2 py-[2px] text-[10.5px] font-bold text-good">
                      FREEZE AVAILABLE
                    </span>
                  )}
                </p>
              </div>

              <div>
                <span className={label}>Negative item</span>
                <div className="mt-2 flex flex-wrap gap-2">
                  {CATEGORIES.map((c) => (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => setCategory(c.id)}
                      className={`rounded-full border px-3.5 py-2 text-[12.5px] font-medium transition-all ${
                        category === c.id
                          ? "border-brand bg-tint text-brand"
                          : "border-line bg-white text-subtle hover:border-brand/50 hover:text-brand"
                      }`}
                    >
                      {c.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-[1fr_110px] gap-3">
                <div>
                  <label className={label} htmlFor="lab-creditor">
                    Furnisher / creditor
                  </label>
                  <input
                    id="lab-creditor"
                    className={`mt-2 ${field}`}
                    value={creditor}
                    onChange={(e) => setcreditor(e.target.value)}
                    placeholder="e.g. Midland Funding LLC"
                  />
                </div>
                <div>
                  <label className={label} htmlFor="lab-acct">
                    Acct · last 4
                  </label>
                  <input
                    id="lab-acct"
                    className={`mt-2 ${field}`}
                    value={accountRef}
                    onChange={(e) => setAccountRef(e.target.value)}
                    placeholder="4821"
                    maxLength={4}
                  />
                </div>
              </div>

              <div>
                <label className={label} htmlFor="lab-note">
                  Extra context (optional)
                </label>
                <textarea
                  id="lab-note"
                  rows={3}
                  className={`mt-2 resize-none ${field}`}
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="Anything the bureau should know…"
                />
              </div>
            </div>

            {error && (
              <p
                role="alert"
                className="mt-4 rounded-xl border border-[#9E1B32]/25 bg-[#FDEBEB] px-4 py-3 text-[13px] text-[#9E1B32]"
              >
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={!canSubmit}
              className="mt-6 inline-flex h-[52px] w-full items-center justify-center gap-2 rounded-full bg-brand text-[15px] font-semibold text-white transition-all hover:-translate-y-[2px] hover:bg-brand-700 disabled:cursor-not-allowed disabled:opacity-55"
            >
              {loading ? (
                <>
                  <IconRefresh width={18} height={18} className="animate-spin" />
                  KyKyAI is writing…
                </>
              ) : (
                <>
                  Generate dispute letter
                  <IconArrow width={18} height={18} />
                </>
              )}
            </button>

            <p className="mt-4 text-[11.5px] leading-[1.55] text-mute">
              Demo only. Nothing here is legal advice, and generated letters are
              saved to your KyKyDispute account history so you can revisit
              every attack.
            </p>
          </form>

          {/* ---- letter output ---- */}
          <div className="relative overflow-hidden rounded-[22px] border border-line bg-[#0F1117]">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 px-6 py-4">
              <div className="flex items-center gap-2.5">
                <span className="h-2.5 w-2.5 rounded-full bg-[#FF5F57]" />
                <span className="h-2.5 w-2.5 rounded-full bg-[#FEBC2E]" />
                <span className="h-2.5 w-2.5 rounded-full bg-[#28C840]" />
                <span className="ml-2 text-[12px] font-medium text-white/50">
                  attack-{String(result?.id ?? "draft").padStart(4, "0")}.txt
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={copy}
                  disabled={!result}
                  className="inline-flex items-center gap-1.5 rounded-full border border-white/12 px-3.5 py-2 text-[12px] font-semibold text-white/80 transition-colors hover:border-white/30 hover:text-white disabled:opacity-40"
                >
                  {copied ? <IconCheck width={14} height={14} /> : <IconCopy width={14} height={14} />}
                  {copied ? "Copied" : "Copy"}
                </button>
                <button
                  type="button"
                  onClick={download}
                  disabled={!result}
                  className="inline-flex items-center gap-1.5 rounded-full bg-white px-3.5 py-2 text-[12px] font-semibold text-ink transition-colors hover:bg-tint disabled:opacity-40"
                >
                  <IconArrow width={14} height={14} />
                  Download
                </button>
              </div>
            </div>

            {result ? (
              <div className="relative">
                <div className="flex flex-wrap gap-2 border-b border-white/10 px-6 py-4">
                  <span className="rounded-full bg-brand/20 px-3 py-1.5 text-[11.5px] font-semibold text-brand-soft">
                    Projected impact {result.impact.score}
                  </span>
                  <span className="rounded-full bg-white/8 px-3 py-1.5 text-[11.5px] font-semibold text-white/70">
                    Removal odds: {result.impact.odds}
                  </span>
                  <span className="rounded-full bg-good/20 px-3 py-1.5 text-[11.5px] font-semibold text-[#5BE3B4]">
                    FCRA §611 cited
                  </span>
                </div>
                <pre className="max-h-[620px] overflow-auto px-6 py-7 font-sans text-[12.6px] leading-[1.85] whitespace-pre-wrap text-white/82">
                  {result.letter}
                </pre>
              </div>
            ) : (
              <div className="flex min-h-[520px] flex-col items-center justify-center px-8 py-16 text-center">
                <span className="flex h-16 w-16 items-center justify-center rounded-2xl border border-white/12 bg-white/[0.06] text-brand-soft">
                  <IconSpark width={28} height={28} />
                </span>
                <p className="mt-6 max-w-[330px] text-[16px] leading-[1.6] text-white/60">
                  Your generated letter will appear here — fully formatted,
                  ready to print, sign and mail.
                </p>
                <p className="mt-3 text-[12px] uppercase tracking-[0.16em] text-white/35">
                  Nothing sent until you say so
                </p>
              </div>
            )}

            {/* paper grain overlay */}
            <div className="pointer-events-none absolute inset-0 grid-dots opacity-[0.18]" />
          </div>
        </div>
      </div>
    </section>
  );
}
