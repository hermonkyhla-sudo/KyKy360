import {
  Button,
  IconChart,
  IconSpark,
  SectionHead,
} from "@/components/Brand";

const PAINS = [
  "\"What? Why did my credit score go down?\"",
  "\"I am just not able to get rid of this interest on my card!\"",
  "\"Why can't I get an increase on my credit limit?\"",
  "\"It's been months and I just can't get approved for my new home.\"",
  "\"I just can't catch a break with all of this interest piling up on me.\"",
  "\"Where did all these negative accounts come from?\"",
];

export default function PainPoints() {
  return (
    <>
      {/* ---------------- Pain points ---------------- */}
      <section className="relative overflow-hidden bg-section py-20 lg:py-28">
        <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-line" />
        <div className="mx-auto max-w-[1450px] px-4 sm:px-6 lg:px-8">
          <SectionHead
            eyebrow="Your AI-Powered Credit Assistant"
            eyebrowIcon={<IconSpark width={14} height={14} />}
            title={
              <>
                Millions endure a struggle due to{" "}
                <span className="text-brand">poor credit scores</span>, you can
                avoid that
              </>
            }
            sub="Join 100,000+ users who've improved their credit with our DIY credit repair tools. Dispute errors, track progress, and reach your dream score faster."
          />

          <div className="mt-14 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {PAINS.map((p, i) => (
              <figure
                key={p}
                className={`anim-rise group relative rounded-2xl border border-line bg-white p-7 transition-all duration-300 hover:-translate-y-1 hover:border-brand/35 hover:shadow-[0_30px_60px_-30px_rgba(41,93,236,0.5)] ${
                  i % 3 === 1 ? "lg:translate-y-6" : ""
                }`}
                style={{ animationDelay: `${i * 70}ms` }}
              >
                <span
                  className="absolute -top-3 left-7 text-[42px] leading-none font-black text-tint select-none"
                  aria-hidden
                >
                  &ldquo;
                </span>
                <blockquote className="relative text-[17px] leading-[1.55] font-medium tracking-[-0.3px] text-ink">
                  {p}
                </blockquote>
                <figcaption className="mt-6 flex items-center gap-2 text-[12px] font-semibold uppercase tracking-[0.13em] text-mute">
                  <span className="h-[6px] w-[6px] rounded-full bg-brand" />
                  Sound familiar?
                </figcaption>
              </figure>
            ))}
          </div>

          <div className="mt-14 text-center">
            <Button href="#get-started" size="lg">
              Get Started
            </Button>
          </div>
        </div>
      </section>

      {/* ---------------- Full control ---------------- */}
      <section className="relative overflow-hidden bg-white py-20 lg:py-28">
        <div className="pointer-events-none absolute -right-32 top-10 h-[520px] w-[520px] rounded-full bg-[radial-gradient(closest-side,rgba(228,236,255,0.9),transparent)]" />
        <div className="relative mx-auto max-w-[1450px] px-4 sm:px-6 lg:px-8">
          <div className="grid items-start gap-12 lg:grid-cols-[1.05fr_1fr]">
            <div>
              <SectionHead
                align="left"
                eyebrow="Full control of your Credit"
                eyebrowIcon={<IconChart width={14} height={14} />}
                title={
                  <>
                    Equipping you with the ability to take full control of your{" "}
                    <span className="text-brand">financial health</span>
                  </>
                }
                sub={
                  <>
                    At KyKyDispute, we aim to be more than just another credit
                    app. We strive to become your trusted partner in your
                    pocket, dedicated to helping you on your financial{" "}
                    <em className="text-ink not-italic underline decoration-brand decoration-2 underline-offset-4">
                      journey
                    </em>
                    .
                  </>
                }
              />
              <div className="mt-9 flex flex-wrap gap-3">
                <Button href="#how">See how it works</Button>
                <Button href="#lab" variant="outline">
                  Generate a sample letter
                </Button>
              </div>
            </div>

            <div className="grid gap-5">
              <div className="rounded-[22px] border border-line bg-tint-soft p-8">
                <p className="text-[22px] leading-[1.25] font-bold tracking-[-0.7px] text-ink sm:text-[26px]">
                  AI that helps you take control of your{" "}
                  <span className="text-brand">credit future</span>
                </p>
                <div className="mt-6 space-y-5">
                  <div className="flex gap-4">
                    <span className="mt-1 inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white text-brand">
                      <IconChart width={20} height={20} />
                    </span>
                    <div>
                      <p className="text-[16px] font-semibold tracking-[-0.3px] text-ink">
                        Financial overview &amp; scores from all 3 bureaus
                      </p>
                      <p className="mt-1.5 text-[14.5px] leading-[1.6] text-subtle">
                        Cost should never be a barrier when it comes to
                        improving personal financial health, and we stand by
                        this.
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <span className="mt-1 inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white text-brand">
                      <IconSpark width={20} height={20} />
                    </span>
                    <div>
                      <p className="text-[16px] font-semibold tracking-[-0.3px] text-ink">
                        AI disputing engine that does the hard work for you
                      </p>
                      <p className="mt-1.5 text-[14.5px] leading-[1.6] text-subtle">
                        Our AI engine reviews and highlights the negative items
                        in your report — you&apos;ll know exactly what to
                        attack.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="rounded-[22px] border border-line bg-white p-8">
                <div className="flex items-end justify-between gap-6">
                  <div>
                    <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-mute">
                      Tracked this year
                    </p>
                    <p className="mt-2 text-[38px] font-extrabold leading-none tracking-[-2px] text-ink">
                      389,000
                      <span className="ml-2 text-[16px] font-semibold tracking-[-0.3px] text-brand">
                        points gained
                      </span>
                    </p>
                    <p className="mt-2 text-[13px] text-subtle">
                      Collective credit score points gained by KyKyDispute
                      users across all tracked accounts.
                    </p>
                  </div>
                </div>
                <div className="mt-6 flex h-[86px] items-end gap-1.5">
                  {[26, 38, 34, 48, 44, 62, 58, 74, 82, 96].map((h, i) => (
                    <span
                      key={i}
                      className="flex-1 rounded-t-[5px] bg-gradient-to-t from-brand/25 to-brand"
                      style={{ height: `${h}%` }}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
