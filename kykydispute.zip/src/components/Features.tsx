import {
  IconChart,
  IconFilter,
  IconMail,
  IconShield,
  IconSpark,
  IconTrash,
  SectionHead,
} from "@/components/Brand";

const CATEGORIES = [
  {
    label: "Collections",
    body: "Late medical bills, old debts, and collections that may be inaccurately reported.",
    color: "#295DEC",
  },
  {
    label: "Charge-offs",
    body: "Cards, auto, and personal loans marked as charge-offs that may contain errors.",
    color: "#9E1B32",
  },
  {
    label: "Late Payments",
    body: "30, 60, 90+ day late payment history that may be incorrectly documented.",
    color: "#0E9F6E",
  },
  {
    label: "Credit Inquiries",
    body: "Unauthorized hard pulls and inquiries that you didn't approve affecting your score.",
    color: "#00a6ca",
  },
  {
    label: "Public Records",
    body: "Bankruptcies, tax liens, and judgments that may be outdated or inaccurate.",
    color: "#787879",
  },
  {
    label: "Medical Records",
    body: "Wrong names, addresses, and account mix-ups from your past.",
    color: "#1A3FA8",
  },
];

const FEATURES = [
  {
    icon: <IconSpark width={22} height={22} />,
    title: "AI Dispute Letter Generator",
    body: "No templates. Our AI analyzes your credit profile and generates personalized, legally-compliant letters that bureaus & creditors actually respond to.",
    wide: true,
  },
  {
    icon: <IconMail width={22} height={22} />,
    title: "Mail 10+ letters in just a click",
    body: "Our AI automatically identifies questionable items across all bureaus and launches targeted attacks simultaneously with one click.",
    wide: true,
  },
  {
    icon: <IconFilter width={22} height={22} />,
    title: "Automatic negative account filtering",
    body: "Not all negative items are worth disputing. Our AI ranks every mark by removal probability and score impact, focusing on disputes that will move your score the most.",
  },
  {
    icon: <IconChart width={22} height={22} />,
    title: "Credit report progress tracker",
    body: "Watch your score climb in real-time. Track every dispute, monitor bureau responses, and see exactly how each removal impacts your credit score across all three bureaus.",
  },
  {
    icon: <IconShield width={22} height={22} />,
    title: "Money-back guarantee like no other",
    body: "We guarantee score improvement or you get every penny back. Our system automatically handles all bureau responses — no manual follow-up required.",
  },
];

export default function Features() {
  return (
    <>
      {/* ------------- Dispute negative items ------------- */}
      <section className="relative overflow-hidden bg-white py-20 lg:py-28">
        <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-line" />
        <div className="relative mx-auto max-w-[1450px] px-4 sm:px-6 lg:px-8">
          <SectionHead
            eyebrow="Dispute Negative Items"
            eyebrowIcon={<IconTrash width={14} height={14} />}
            title={
              <>
                Dispute all of those{" "}
                <span className="inline-flex translate-y-[5px] items-center gap-1.5 rounded-full bg-[#FDEBEB] px-3.5 py-1 align-middle">
                  <IconTrash width={22} height={22} className="text-[#9E1B32]" />
                </span>{" "}
                <span className="text-[#9E1B32]">negative items</span> from your
                credit report
              </>
            }
            sub="Our AI credit repair software helps you dispute and fight negative items on your credit affecting you."
          />

          <div className="mt-14 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {CATEGORIES.map((c, i) => (
              <article
                key={c.label}
                className="group relative overflow-hidden rounded-[20px] border border-line bg-white p-8 transition-all duration-300 hover:-translate-y-1.5 hover:shadow-[0_36px_70px_-34px_rgba(41,93,236,0.5)]"
              >
                <span
                  className="absolute inset-x-0 top-0 h-[3px] origin-left scale-x-0 transition-transform duration-300 group-hover:scale-x-100"
                  style={{ background: c.color }}
                />
                <span
                  className="inline-flex h-[62px] w-[62px] items-center justify-center rounded-[18px]"
                  style={{ background: `${c.color}14`, color: c.color }}
                >
                  <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
                    {i % 3 === 0 ? (
                      <path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v6M14 11v6" />
                    ) : i % 3 === 1 ? (
                      <path d="M12 2.5 20 6v6c0 5-3.4 8.7-8 9.5-4.6-.8-8-4.5-8-9.5V6l8-3.5Z" />
                    ) : (
                      <path d="M4 20V10M10 20V4M16 20v-7M22 20H2" />
                    )}
                  </svg>
                </span>
                <h3 className="mt-6 text-[21px] font-bold tracking-[-0.7px] text-ink">
                  {c.label}
                </h3>
                <p className="mt-3 text-[15px] leading-[1.6] text-subtle">
                  {c.body}
                </p>
                <a
                  href="#lab"
                  className="mt-6 inline-flex items-center gap-1.5 text-[14px] font-semibold text-brand"
                >
                  Dispute this
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="transition-transform group-hover:translate-x-1">
                    <path d="M5 12h14M13 6l6 6-6 6" />
                  </svg>
                </a>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* ------------- Advanced features ------------- */}
      <section id="features" className="relative overflow-hidden bg-night py-20 lg:py-28">
        <div className="pointer-events-none absolute inset-0 grid-dots opacity-[0.3]" />
        <div className="pointer-events-none absolute right-[-180px] top-[-120px] h-[520px] w-[520px] rounded-full bg-[radial-gradient(closest-side,rgba(41,93,236,0.5),transparent)]" />

        <div className="relative mx-auto max-w-[1450px] px-4 sm:px-6 lg:px-8">
          <SectionHead
            tone="dark"
            eyebrow="How it works"
            eyebrowIcon={<IconSpark width={14} height={14} />}
            title={
              <>
                Advanced <span className="text-brand-soft">AI credit</span>{" "}
                repair features
              </>
            }
            sub="From dispute letters to progress tracking, AI handles the hard work so you don't have to."
          />

          <div className="mt-14 grid grid-cols-1 gap-5 lg:grid-cols-2">
            {FEATURES.map((f, i) => (
              <article
                key={f.title}
                className={`group relative overflow-hidden rounded-[22px] border border-white/10 bg-white/[0.045] p-8 transition-all duration-300 hover:-translate-y-1 hover:border-brand/50 hover:bg-white/[0.07] ${
                  i >= 2 ? "lg:col-span-1" : ""
                }`}
              >
                <div className="flex items-start gap-5">
                  <span className="inline-flex h-[52px] w-[52px] shrink-0 items-center justify-center rounded-[16px] bg-brand/20 text-brand-soft">
                    {f.icon}
                  </span>
                  <div>
                    <h3 className="text-[20px] leading-[1.25] font-bold tracking-[-0.7px] text-white">
                      {f.title}
                    </h3>
                    <p className="mt-3 text-[15px] leading-[1.65] text-white/65">
                      {f.body}
                    </p>
                  </div>
                </div>
              </article>
            ))}

            {/* stat tile — breaks the card rhythm */}
            <article className="relative overflow-hidden rounded-[22px] border border-brand/40 bg-gradient-to-br from-brand to-brand-900 p-8">
              <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-white/70">
                KyKyAI engine
              </p>
              <p className="mt-4 text-[52px] font-extrabold leading-none tracking-[-2.5px] text-white">
                ~1,000,000
              </p>
              <p className="mt-3 max-w-[360px] text-[15px] leading-[1.6] text-white/80">
                dispute letters processed by our proprietary KyKyAI engine on
                behalf of consumers with erroneous items.
              </p>
            </article>
          </div>
        </div>
      </section>
    </>
  );
}
