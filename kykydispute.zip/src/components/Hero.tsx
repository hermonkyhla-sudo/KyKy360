import {
  Button,
  IconChart,
  IconCheck,
  IconShield,
  IconSpark,
  Stars,
} from "@/components/Brand";
import Header from "@/components/Header";

export function ReviewPills({
  tone = "light",
  className = "",
}: {
  tone?: "light" | "dark";
  className?: string;
}) {
  return (
    <div
      className={`flex flex-wrap items-center justify-center gap-x-4 gap-y-2 text-[13px] ${
        tone === "dark" ? "text-white/70" : "text-subtle"
      } ${className}`}
    >
      <span className="inline-flex items-center gap-2">
        <Stars value={5} />
        <strong className="font-semibold text-ink">4.8 Stars</strong>
        <span className={tone === "dark" ? "text-white/50" : "text-mute"}>·</span>
        <span>4,000+ Reviews</span>
      </span>
      <span
        className={`h-4 w-px ${tone === "dark" ? "bg-white/15" : "bg-line"}`}
        aria-hidden
      />
      <span className="inline-flex items-center gap-2">
        <span className="inline-flex h-5 w-5 items-center justify-center rounded-full bg-[#00B67A] text-[10px] font-black text-white">
          ★
        </span>
        <span>Trustpilot 4.4/5 · 1,861 Reviews</span>
      </span>
    </div>
  );
}

export default function Hero() {
  return (
    <div id="top">
      <Header />

      <section className="relative overflow-hidden bg-white pt-10 pb-16 sm:pt-12 lg:pt-14 lg:pb-24">
        {/* material: claw-score glow + dotted grid */}
        <div className="pointer-events-none absolute inset-0 grid-dots opacity-[0.55]" />
        <div className="pointer-events-none absolute -top-40 left-1/2 h-[620px] w-[1100px] -translate-x-1/2 rounded-full bg-[radial-gradient(closest-side,rgba(41,93,236,0.16),transparent)]" />
        <div className="pointer-events-none absolute top-[220px] -left-24 h-[320px] w-[320px] rounded-full bg-[radial-gradient(closest-side,rgba(169,192,255,0.5),transparent)] blur-2xl" />

        <div className="relative mx-auto max-w-[1450px] px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-[1120px] text-center">
            <a
              href="#reviews"
              className="anim-rise inline-flex items-center gap-2.5 rounded-full border border-line bg-[#f5f5f7] px-4 py-2 text-[12.5px] font-medium tracking-[-0.2px] transition-colors hover:border-brand/40 hover:bg-white"
            >
              <Stars value={5} size={13} />
              <span className="text-ink">Google 4.8</span>
              <span className="h-3.5 w-px bg-line" />
              <span className="inline-flex h-4 w-4 items-center justify-center rounded-full bg-[#00B67A] text-[9px] font-black text-white">
                ★
              </span>
              <span className="text-ink">Trustpilot 4.4</span>
            </a>

            <p className="anim-rise mt-3 text-[13px] text-subtle">
              Rated 4.8 Stars by 4,000+ Users
            </p>

            <h1
              className="anim-rise mt-5 text-[40px] font-extrabold leading-[1.06] tracking-[-2px] text-ink sm:text-[56px] lg:text-[74px]"
              style={{ animationDelay: "60ms" }}
            >
              The most advanced{" "}
              <span className="relative whitespace-nowrap text-brand">
                AI Financial
                <svg
                  className="absolute -bottom-1 left-0 h-[10px] w-full"
                  viewBox="0 0 300 12"
                  preserveAspectRatio="none"
                  aria-hidden
                >
                  <path
                    d="M2 8c60-6 120-7 180-4 40 2 80 3 116 1"
                    stroke="#A9C0FF"
                    strokeWidth="5"
                    fill="none"
                    strokeLinecap="round"
                  />
                </svg>
              </span>{" "}
              <span className="inline-flex translate-y-[6px] items-center gap-1.5 rounded-full border border-brand/25 bg-tint-soft px-3 py-1 align-middle sm:translate-y-[10px]">
                <IconChart width={22} height={22} className="text-brand" />
                <span
                  className="text-[20px] font-extrabold tracking-[-1px] text-brand sm:text-[28px] lg:text-[34px]"
                  style={{ animation: "db-count 1.4s ease-out both" }}
                >
                  752
                </span>
              </span>{" "}
              app ever created
            </h1>

            <p
              className="anim-rise mx-auto mt-7 max-w-[720px] text-[16px] leading-[1.6] tracking-[-0.2px] text-subtle sm:text-[19px]"
              style={{ animationDelay: "120ms" }}
            >
              Your ultimate DIY credit repair dispute assistant tool powered by
              AI with a{" "}
              <strong className="font-semibold text-ink">
                110% money-back guarantee
              </strong>
              .
            </p>

            <div
              className="anim-rise mt-8 flex flex-wrap items-center justify-center gap-3"
              style={{ animationDelay: "180ms" }}
            >
              <Button href="#get-started" size="lg">
                Get Started
              </Button>
              <Button href="#lab" variant="outline" size="lg">
                <IconSpark width={18} height={18} />
                Try the AI letter engine
              </Button>
            </div>

            <p className="mx-auto mt-6 max-w-[760px] text-[13px] leading-[1.6] text-mute">
              Making your dispute letters with KyKyDispute&apos;s engine is
              free. But you need KyKy Credit Monitoring to do it — it&apos;s
              $49.99 a month. If you have KyKy Credit Monitoring, you can make
              as many letters as you want in KyKyDispute.
            </p>
          </div>

          {/* Hero visual */}
          <div className="relative mx-auto mt-12 max-w-[1180px] lg:mt-16">
            <div className="anim-pop relative overflow-hidden rounded-[28px] border border-line bg-gradient-to-b from-tint-soft to-white p-2 shadow-[0_60px_120px_-50px_rgba(41,93,236,0.55)]">
              <div className="relative overflow-hidden rounded-[22px]">
                <img
                  src="images/hero-device.png"
                  alt="KyKyDispute AI credit repair dashboard showing score improvements across all three bureaus"
                  className="h-[280px] w-full object-cover object-center sm:h-[420px] lg:h-[560px]"
                  loading="eager"
                />
                <div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(255,255,255,0.28)_0%,rgba(41,93,236,0.06)_45%,rgba(11,18,40,0.42)_100%)]" />
                <div className="absolute inset-x-0 bottom-0 flex flex-wrap items-end justify-between gap-4 p-5 sm:p-8">
                  <div className="rounded-2xl border border-white/25 bg-white/12 px-5 py-4 backdrop-blur-md">
                    <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-white/70">
                      Average user increase
                    </p>
                    <p className="mt-1 text-[32px] font-extrabold leading-none tracking-[-1.6px] text-white sm:text-[42px]">
                      +92 pts
                    </p>
                  </div>
                  <div className="hidden items-center gap-3 rounded-2xl border border-white/25 bg-white/12 px-5 py-4 backdrop-blur-md sm:flex">
                    <IconShield width={22} height={22} className="text-white" />
                    <div>
                      <p className="text-[13px] font-semibold text-white">
                        110% money-back guarantee
                      </p>
                      <p className="text-[11.5px] text-white/70">
                        No contracts. No waiting.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 rounded-2xl border border-white/25 bg-white/12 px-5 py-4 backdrop-blur-md">
                    <IconCheck width={20} height={20} className="text-white" />
                    <p className="text-[13px] font-semibold text-white">
                      3-bureau monitoring included
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* floating claw shards */}
            <svg
              className="anim-claw pointer-events-none absolute -right-6 -top-10 h-[120px] w-[120px] opacity-70"
              viewBox="0 0 120 120"
              aria-hidden
            >
              <g fill="#295DEC">
                <path d="M12 8c18 14 34 34 46 60-16-11-32-28-45-48a2 2 0 0 1-1-12Z" />
                <path d="M42 4c18 14 34 36 45 62-16-12-31-30-44-50a2 2 0 0 1-1-12Z" />
                <path d="M72 8c17 15 31 37 41 63-15-12-29-31-41-51a2 2 0 0 1 0-12Z" />
              </g>
            </svg>
          </div>

          <div className="mt-10">
            <ReviewPills />
          </div>
        </div>
      </section>
    </div>
  );
}
