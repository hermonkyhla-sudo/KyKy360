"use client";

import { useState } from "react";
import { IconArrow, IconCheck, IconRefresh } from "@/components/Brand";

const GOALS = [
  "Remove collections & charge-offs",
  "Get approved for a mortgage",
  "Raise my FICO® by 100+ points",
  "Lower my interest rates",
];

const PLANS = ["KyKy Credit Monitoring · $49.99/mo", "ProCreditWatch · $59.99/mo"];

export default function LeadForm() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [goal, setGoal] = useState(GOALS[0]);
  const [plan, setPlan] = useState(PLANS[0]);
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, goal, plan }),
      });
      const data = (await res.json()) as { error?: string };
      if (!res.ok) throw new Error(data.error ?? "Something went wrong");
      setDone(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  }

  const input =
    "w-full rounded-xl border border-line bg-white px-4 py-3.5 text-[15px] text-ink outline-none transition-colors placeholder:text-mute focus:border-brand";
  const label =
    "block text-[11px] font-semibold uppercase tracking-[0.14em] text-subtle";

  if (done) {
    return (
      <div className="anim-pop rounded-[22px] border border-good/30 bg-good/8 p-8 text-center">
        <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-good text-white">
          <IconCheck width={26} height={26} />
        </span>
        <h3 className="mt-5 text-[22px] font-bold tracking-[-0.7px] text-ink">
          You&apos;re on the list, {name.split(" ")[0] || "friend"}
        </h3>
        <p className="mx-auto mt-3 max-w-[380px] text-[14.5px] leading-[1.6] text-subtle">
          We saved your goal — <strong className="text-ink">{goal}</strong>. Check{" "}
          <strong className="text-ink">{email}</strong> for your activation link
          and next steps.
        </p>
      </div>
    );
  }

  return (
    <form
      onSubmit={submit}
      className="rounded-[22px] border border-line bg-white p-7 shadow-[0_36px_80px_-46px_rgba(15,23,42,0.5)]"
    >
      <h3 className="text-[20px] font-bold tracking-[-0.7px] text-ink">
        Create your free KyKyDispute account
      </h3>
      <p className="mt-2 text-[13.5px] leading-[1.6] text-subtle">
        No contracts. No waiting. Cancel anytime.
      </p>

      <div className="mt-6 space-y-4">
        <div>
          <label className={label} htmlFor="lead-name">
            Full name
          </label>
          <input
            id="lead-name"
            required
            className={`mt-2 ${input}`}
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Jordan Rivera"
          />
        </div>
        <div>
          <label className={label} htmlFor="lead-email">
            Email address
          </label>
          <input
            id="lead-email"
            type="email"
            required
            className={`mt-2 ${input}`}
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@email.com"
          />
        </div>
        <div>
          <label className={label} htmlFor="lead-goal">
            Your goal
          </label>
          <select
            id="lead-goal"
            className={`mt-2 ${input}`}
            value={goal}
            onChange={(e) => setGoal(e.target.value)}
          >
            {GOALS.map((g) => (
              <option key={g}>{g}</option>
            ))}
          </select>
        </div>
        <div>
          <label className={label} htmlFor="lead-plan">
            Monitoring plan
          </label>
          <select
            id="lead-plan"
            className={`mt-2 ${input}`}
            value={plan}
            onChange={(e) => setPlan(e.target.value)}
          >
            {PLANS.map((p) => (
              <option key={p}>{p}</option>
            ))}
          </select>
        </div>
      </div>

      {error && (
        <p
          role="alert"
          className="mt-4 rounded-xl border border-[#9E1B32]/25 bg-[#FDEBEB] px-4 py-3 text-[13px] text-[#9E1B32]"
        >
          {error}
        </p>
      )}

      <button
        type="submit"
        disabled={loading}
        className="mt-6 inline-flex h-[52px] w-full items-center justify-center gap-2 rounded-full bg-brand text-[15px] font-semibold text-white transition-all hover:-translate-y-[2px] hover:bg-brand-700 disabled:opacity-60"
      >
        {loading ? (
          <>
            <IconRefresh width={18} height={18} className="animate-spin" />
            Creating account…
          </>
        ) : (
          <>
            Get Started
            <IconArrow width={18} height={18} />
          </>
        )}
      </button>

      <p className="mt-4 flex items-start gap-2 text-[11.5px] leading-[1.55] text-mute">
        <IconCheck width={14} height={14} className="mt-[1px] shrink-0 text-good" />
        Making your dispute letters with KyKyDispute&apos;s engine is free. An
        active 3-bureau monitoring subscription is required to pull reports,
        starting at $49.99/month.
      </p>
    </form>
  );
}
