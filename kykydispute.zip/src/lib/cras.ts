/**
 * Consumer reporting company (CRA) directory.
 *
 * Source: CFPB "List of consumer reporting companies" (current as of
 * January 2025) — the companies that have identified themselves as
 * consumer reporting agencies as defined in the Fair Credit Reporting
 * Act (FTC, May 2023, fcra-may2023-508.pdf). The three nationwide
 * bureaus are listed first. Contact details are the companies' own
 * published consumer-dispute contacts.
 */

export type CraCategory =
  | "nationwide"
  | "employment"
  | "tenant"
  | "deposit"
  | "insurance"
  | "medical"
  | "subprime"
  | "supplementary"
  | "telecom"
  | "retail"
  | "gaming";

export type Cra = {
  id: string;
  name: string;
  cat: CraCategory;
  blurb: string;
  web: string;
  phone: string;
  addr: string;
  /** Accepts a security freeze (per CFPB list "Freeze Report" column). */
  freeze: boolean;
};

export const CRA_CATEGORIES: { id: CraCategory; label: string; blurb: string }[] = [
  { id: "nationwide", label: "Nationwide bureaus", blurb: "The big three whose reports drive most credit, lending and score decisions." },
  { id: "employment", label: "Employment screening", blurb: "Background checks for hiring — work history, criminal records, credentials." },
  { id: "tenant", label: "Tenant screening", blurb: "Rental history, evictions and resident risk scores used by landlords." },
  { id: "deposit", label: "Bank & check screening", blurb: "Checking-account and check-writing history used to approve bank accounts." },
  { id: "insurance", label: "Insurance", blurb: "Claims history and driving behaviour data used to price insurance policies." },
  { id: "medical", label: "Medical", blurb: "Medical and prescription history checked by life and health insurers." },
  { id: "subprime", label: "Low-income & subprime", blurb: "Payday, instalment and alternative-finance payment performance data." },
  { id: "supplementary", label: "Supplementary reports", blurb: "Extra credit and identity data that supplements the nationwide bureaus." },
  { id: "telecom", label: "Telecom & utilities", blurb: "New-service and payment history for phone, cable and utility accounts." },
  { id: "retail", label: "Retail", blurb: "Product-return and exchange-fraud monitoring shared between merchants." },
  { id: "gaming", label: "Gaming & sports betting", blurb: "Casino credit and check-cashing data shared between gaming operators." },
];

export const CRAS: Cra[] = [
  { id: "equifax", name: "Equifax", cat: "nationwide", blurb: "Nationwide consumer reporting company — credit reports, scores and payment history used by most lenders.", web: "https://www.equifax.com/personal/credit-report-services/credit-freeze/", phone: "888-298-0045", addr: "P.O. Box 740256, Atlanta, GA 30374", freeze: true },
  { id: "experian", name: "Experian", cat: "nationwide", blurb: "Nationwide consumer reporting company — credit reports and FICO® scores used by lenders, landlords and employers.", web: "https://www.experian.com/freeze/center.html", phone: "888-397-3742", addr: "P.O. Box 4500, Allen, TX 75013", freeze: true },
  { id: "transunion", name: "TransUnion", cat: "nationwide", blurb: "Nationwide consumer reporting company — credit reports and scores used across lending, rental and employment.", web: "https://www.transunion.com/credit-freeze", phone: "800-916-8800", addr: "P.O. Box 2000, Chester, PA 19016", freeze: true },
  {"id": "accurate-background", "name": "Accurate Background", "cat": "employment", "blurb": "Provides background screening services.", "web": "https://www.accurate.com/my-background-check/", "phone": "800-784-3911", "addr": "200 Spectrum Center Drive Suite 100, Irvine, CA 92618", "freeze": false},
  {"id": "adp-screening-selection-services-inc", "name": "ADP Screening & Selection Services, Inc.", "cat": "employment", "blurb": "Provides background screening services.", "web": "https://www.adpselect.com/login/", "phone": "888-606-7868 (Option 2)", "addr": "2950 East Harmony Road Suite 130, Fort Collins, CO 80528", "freeze": false},
  {"id": "asurint", "name": "Asurint", "cat": "employment", "blurb": "Provides background screening services, including, pre- and post-hire searches and workforce monitoring.", "web": "https://www.asurint.com/candidates", "phone": "800-906-2034", "addr": "P.O. Box 14730, Cleveland, OH 44114", "freeze": false},
  {"id": "backgroundchecks-com", "name": "backgroundchecks.com", "cat": "employment", "blurb": "Provides background screening services and income and employment verification", "web": "https://www.backgroundchecks.com/disputes", "phone": "866-265-6602", "addr": "P.O. Box 353, Chapin, SC 29036", "freeze": false},
  {"id": "blend-insights", "name": "Blend Insights", "cat": "employment", "blurb": "Provides consumer permissioned employment, income and bank asset verification information to lenders.", "web": "https://blend.com/insights/", "phone": "855-520-1012", "addr": "415 Kearney Street, San Francisco, CA 94108", "freeze": true},
  {"id": "ccc-verify", "name": "CCC Verify", "cat": "employment", "blurb": "Provides employment and wage information to lenders, property managers, public assistance agencies, and others", "web": "https://www.cccverify.com/", "phone": "855-901-3099", "addr": "50 Nashua Road, Londonderry, NH 03053", "freeze": false},
  {"id": "certiphi", "name": "Certiphi", "cat": "employment", "blurb": "Provides background screening services tailored to the healthcare industry.", "web": "https://www.certiphi.com/fact-act/", "phone": "800-260-1680", "addr": "P.O. Box 541, Southampton, PA 18966", "freeze": false},
  {"id": "checkr", "name": "Checkr", "cat": "employment", "blurb": "Provides background screening and post-hire workforce monitoring services.", "web": "https://candidate.checkr.com/login#login", "phone": "844-824-3257", "addr": "One Montgomery Street Suite 2400, San Francisco, CA 94104", "freeze": false},
  {"id": "cisive", "name": "Cisive", "cat": "employment", "blurb": "Provides background screening services and post-hire monitoring services.", "web": "https://www2.cisive.com/request-copy-my-report", "phone": "855-881-0716", "addr": "5000 Corporate Ct Suite 203, Holtsville, NY 11742", "freeze": false},
  {"id": "disa-global-solutions-inc", "name": "DISA Global Solutions, Inc.", "cat": "employment", "blurb": "Provides background screening services.", "web": "https://disa.com/contact/applicant-assistance", "phone": "281-673-2400", "addr": "10900 Corporate Centre Drive Suite 250, Houston, TX 77041", "freeze": false},
  {"id": "empinfo-inc", "name": "EmpInfo, Inc.", "cat": "employment", "blurb": "Verifies and provides employment and income information to employers, lenders, rental housing managers and public agencies.", "web": "https://www.empinfo.com/employee/", "phone": "800-274-9694", "addr": "5900 Silver Creek Valley Road, San Jose, CA 95138", "freeze": false},
  {"id": "experian-verify", "name": "Experian Verify", "cat": "employment", "blurb": "Provides income and employment verification information to lenders, employment screeners, and social service agencies.", "web": "https://www.experian.com/employer-services/products/verification-fulfillment/experian-verify/consumer-support", "phone": "866-312-8266", "addr": "P.O. Box 1971, Woodstock, GA 30188", "freeze": false},
  {"id": "fama-technologies", "name": "Fama Technologies", "cat": "employment", "blurb": "Provides social media screening for employers, powered by a team of FCRA-trained analysts.", "web": "https://fama.io/privacy-policy", "phone": "888-748-3281", "addr": "735 State Street Suite 211, Santa Barbara, CA 93101", "freeze": false},
  {"id": "first-advantage-corporation", "name": "First Advantage Corporation", "cat": "employment", "blurb": "Provides background screening and post-hire workforce monitoring services.", "web": "https://fadv.com/candidates/free-report/", "phone": "", "addr": "P.O. Box 105292, Atlanta, GA 30348-5292", "freeze": true},
  {"id": "ferretly", "name": "Ferretly", "cat": "employment", "blurb": "Provides social media screening services by analyzing and surfacing behaviors from publicly sourced information.", "web": "https://www.ferretly.com/", "phone": "", "addr": "16 N. Washington Street, Easton, MD 21601", "freeze": false},
  {"id": "hireright", "name": "HireRight", "cat": "employment", "blurb": "Provides background screening and post-hire workforce monitoring services.", "web": "https://support.hireright.com/north-america-568ca8b6/4-after-your-background-check-1ca64c7f/request-a-copy-of-my-background-report-or-testing-results-94237bd8", "phone": "866-521-6995", "addr": "14002 E. 21st Street, Tulsa, OK 74134", "freeze": false},
  {"id": "intellicorp", "name": "IntelliCorp", "cat": "employment", "blurb": "Provides background screening services with a focus on pre-employment, healthcare and non-profit employment.", "web": "https://www.intellicorp.net/marketing/Applicant-Inquiries", "phone": "888-946-8355 or 866-202-1436 for Spanish", "addr": "3000 Auburn Drive Suite 410, Beachwood, OH 44122", "freeze": false},
  {"id": "openonline", "name": "OPENonline", "cat": "employment", "blurb": "Provides background screening services", "web": "https://services.openonline.com/Pages/Compliance/RequestInformation.aspx", "phone": "877-263-8033 (Option 1)", "addr": "7127 South Riverside Pkwy, Tulsa, OK 74136", "freeze": false},
  {"id": "pinwheel", "name": "Pinwheel", "cat": "employment", "blurb": "Collects consumer permissioned income and employment data for banks, lenders and credit unions.", "web": "https://www.pinwheelapi.com/fcra/consumer-request-form", "phone": "", "addr": "20 W 22nd Street Suite 1101, New York, NY 10010", "freeze": false},
  {"id": "pre-employ-com", "name": "Pre-employ.com", "cat": "employment", "blurb": "Provides background screening services, including continuous monitoring of nationwide databases.", "web": "https://www.pre-employ.com/consumer-resource-information/", "phone": "855-940-3232 or 530-629-5296 (Option 3)", "addr": "P.O. Box 491570, Redding, CA 96049", "freeze": false},
  {"id": "sterling", "name": "Sterling", "cat": "employment", "blurb": "Provides background screening and post-hire workforce monitoring services", "web": "https://www.sterlingcheck.com/about-sterling/fact-act-disclosure/", "phone": "888-889-5248", "addr": "6150 Oak Tree Boulevard Suite 490, Independence, OH 44131", "freeze": false},
  {"id": "the-work-number", "name": "The Work Number", "cat": "employment", "blurb": "Provides employment and income information", "web": "https://employees.theworknumber.com/employment-data-report", "phone": "866-222-5880", "addr": "3470 Rider Trail South, Earth City, MO 63045", "freeze": true},
  {"id": "truework", "name": "Truework", "cat": "employment", "blurb": "Collects data to verify employment and income", "web": "https://help.truework.com/hc/en-us/requests/new?ticket_form_id=4415487281175", "phone": "833-878-3967", "addr": "One Montgomery Street Suite 2400, San Francisco, CA 94104", "freeze": false},
  {"id": "universal-background-screening", "name": "Universal Background Screening", "cat": "employment", "blurb": "Provides background screening services, social media screening, and employment and income verification.", "web": "https://universalbackground.com/", "phone": "877-263-8033 (Option 2)", "addr": "P.O. Box 5920, Scottsdale, AZ 85261", "freeze": false},
  {"id": "amrent", "name": "AmRent", "cat": "tenant", "blurb": "Provides tenant screening services, including employment and income verification, to property management companies.", "web": "https://www.amrent.com/consumer_assistance", "phone": "888-898-6196", "addr": "P.O. Box 530091, Atlanta, GA 30353", "freeze": false},
  {"id": "appfolio-inc", "name": "AppFolio, Inc.", "cat": "tenant", "blurb": "Provides tenant screening services to property management companies and landlords.", "web": "https://www.appfolio.com/consumer", "phone": "866-359-3630", "addr": "70 Castilian Drive, Goleta, CA 93117", "freeze": false},
  {"id": "contemporary-information-corp", "name": "Contemporary Information Corp. (CIC)", "cat": "tenant", "blurb": "Provides background screening services for landlords and residential real estate management companies.", "web": "https://www.cicreports.com/consumer-assistance/", "phone": "888-316-4242", "addr": "3700 Crestwood Pkwy #300, Duluth, GA 30096", "freeze": false},
  {"id": "experian-rentbureau", "name": "Experian RentBureau", "cat": "tenant", "blurb": "Provides rent payment history data to the multifamily housing industry through tenant screening companies", "web": "https://www.experian.com/rental-property-solutions/rentbureau", "phone": "877-704-4519", "addr": "P.O. Box 26, Allen, TX 75013", "freeze": false},
  {"id": "first-advantage-resident-solutions", "name": "First Advantage Resident Solutions", "cat": "tenant", "blurb": "Provides tenant screening services for property managers, owners, and leasing agents.", "web": "https://fadv.com/industries/residential-tenant-background-checks/", "phone": "800-845-6004", "addr": "P.O. Box 105292, Atlanta, GA 30348-5292", "freeze": true},
  {"id": "real-page-inc", "name": "Real Page, Inc. (LeasingDesk)", "cat": "tenant", "blurb": "Provides consumer data and resident screening services to rental property owners and managers", "web": "https://www.realpage.com/support/consumer/", "phone": "866-934-1124", "addr": "2201 Lakeside Blvd., Richardson, TX 75082", "freeze": false},
  {"id": "rentgrow-inc", "name": "RentGrow, Inc.", "cat": "tenant", "blurb": "Provides resident screening services to property owners and managers", "web": "https://www.rentgrow.com/learn-now/", "phone": "800-898-1351", "addr": "117 Huntington Avenue Suite 1703 #74213, Boston, MA 02115", "freeze": false},
  {"id": "saferent-solutions", "name": "SafeRent Solutions", "cat": "tenant", "blurb": "Provides resident screening and an applicant resident risk score to property managers and landlords", "web": "https://saferentsolutions.com/consumer-support/", "phone": "888-333-2413", "addr": "P.O. Box 3890, Coppell, TX 75019", "freeze": true},
  {"id": "screening-reports-inc", "name": "Screening Reports, Inc.", "cat": "tenant", "blurb": "Provides background screening services to rental property managers and building owners in the multifamily housing industry.", "web": "https://screeningreports.com/en/contact-page/", "phone": "954-526-6110", "addr": "2900 Monarch Lakes Blvd Suite 201, Miramar, FL 33027", "freeze": false},
  {"id": "transunion-rental-screening-solutions-inc", "name": "TransUnion Rental Screening Solutions, Inc. (TransUnion SmartMove)", "cat": "tenant", "blurb": "Provides tenant screening reports, estimated income insights, resident risk scores, and leasing recommendations.", "web": "https://www.mysmartmove.com/transunion-smartmove-frequently-asked-questions/tenant-frequently-asked-questions", "phone": "800-230-9376 (Option 4)", "addr": "P.O. Box 800, Woodlyn, PA 19094", "freeze": false},
  {"id": "certegy-payment-solutions-llc", "name": "Certegy Payment Solutions, LLC", "cat": "deposit", "blurb": "Provides check and ACH verification services for financial institutions and a variety of consumer facing industries.", "web": "https://www.askcertegy.com/FACT.jsp", "phone": "800-237-3826", "addr": "P.O. Box 908, Grand Junction, CO 81502", "freeze": false},
  {"id": "chex-systems-inc", "name": "Chex Systems, Inc.", "cat": "deposit", "blurb": "Provides account verification services primarily for financial institutions", "web": "http://www.chexsystems.com/", "phone": "800-428-9623", "addr": "P.O. Box 583399, Minneapolis, MN 55458", "freeze": true},
  {"id": "crosscheck-inc", "name": "CrossCheck, Inc.", "cat": "deposit", "blurb": "Provides check verification and guarantee services primarily for automotive sales and repair, building supply and home services.", "web": "https://consumerinquiry.cross-check.com/RequestForReport/submitrequest", "phone": "800-843-0760", "addr": "P.O. Box 6008, Petaluma, CA 94955-6008", "freeze": false},
  {"id": "early-warning-services-llc", "name": "Early Warning Services, LLC", "cat": "deposit", "blurb": "Assists financial institutions, check acceptance companies, payment processors and other businesses with fraud and risk data.", "web": "http://www.earlywarning.com/consumer-information.html", "phone": "800-745-1560", "addr": "5801 N. Pima Road, Scottsdale, AZ 85250", "freeze": false},
  {"id": "global-payments-check-services-llc", "name": "Global Payments Check Services LLC", "cat": "deposit", "blurb": "Provides check screening and verification services for various consumer-facing industries, including retail.", "web": "https://www.globalpayments.com/notices/facta", "phone": "800-638-4600 (Ext. 410)", "addr": "P.O. Box 480357, Niles, IL 60714-0357", "freeze": false},
  {"id": "telecheck-services-inc", "name": "TeleCheck Services, Inc.", "cat": "deposit", "blurb": "Assists retailers, financial institutions and other businesses in reducing fraud and other risks associated with check acceptance.", "web": "https://getassistance.telecheck.com/consumer-file-report/", "phone": "800-366-2425", "addr": "P.O. Box 6806, Hagerstown, MD 21741-6806", "freeze": false},
  {"id": "a-plus-property", "name": "A-Plus Property (by Verisk)", "cat": "insurance", "blurb": "Collects and reports insurance claims and loss history associated with homes, auto or personal property", "web": "https://fcra.verisk.com/#/", "phone": "800-627-3487", "addr": "P.O. Box 5404, Mt. Laurel, NJ 08054", "freeze": false},
  {"id": "arity", "name": "Arity", "cat": "insurance", "blurb": "Collects and reports driving behavior data and score using telematics technology collected through mobile devices.", "web": "https://arityservices.consumerprivacyinfo.com/", "phone": "800-654-1412", "addr": "P.O. Box 227328, Dallas, TX 75222-7238", "freeze": false},
  {"id": "connected-analytic-services", "name": "Connected Analytic Services (CAS)", "cat": "insurance", "blurb": "Collects and reports driving behavior data using telematics technology collected through mobile devices.", "web": "https://connectedanalyticservices.com/", "phone": "", "addr": "7600 Windrose Avenue Suite G-240, Plano, TX 75024", "freeze": false},
  {"id": "drivers-history", "name": "Drivers History", "cat": "insurance", "blurb": "Provides reports to insurance clients that underwrite policies and investigate insurance claims", "web": "https://www.drivershistory.com/support/fcra-disclosure-statement", "phone": "855-694-1555", "addr": "P.O. Box 600, Woodlyn, PA 19094", "freeze": false},
  {"id": "insurance-information-exchange", "name": "Insurance Information Exchange (iiX)", "cat": "insurance", "blurb": "Collects and reports motor vehicle records, including traffic violation data to insurance providers and employers", "web": "https://www.verisk.com/resources/transportation-employment-screening-reports-on-consumers-adverse-action/", "phone": "800-683-8553", "addr": "1574 Crescent Pointe Pkwy, College Station, TX 77845", "freeze": false},
  {"id": "lexisnexis-c-l-u-e-telematics-ondemand", "name": "LexisNexis C.L.U.E. & Telematics OnDemand", "cat": "insurance", "blurb": "Provides auto and property insurance claims history (C.L.U.E.) and driving behaviour data to insurers.", "web": "https://consumer.risk.lexisnexis.com/", "phone": "866-897-8126", "addr": "P.O. Box 105108, Atlanta, GA 30348-5108", "freeze": true},
  {"id": "mib-inc", "name": "MIB, Inc.", "cat": "medical", "blurb": "Collects information about medical conditions and hazardous avocations", "web": "https://www.mib.com/request_your_record.html", "phone": "866-692-6901", "addr": "50 Braintree Hill Park Suite 400, Braintree, MA 02184-8734", "freeze": false},
  {"id": "milliman-intelliscript", "name": "Milliman IntelliScript", "cat": "medical", "blurb": "Collects prescription drug purchase history for quantifying the relative mortality risk of life insurance applicants.", "web": "https://www.rxhistories.com/for-consumers/", "phone": "877-211-4816", "addr": "P.O. Box 2223, Brookfield, WI 53008", "freeze": false},
  {"id": "clarity-services", "name": "Clarity Services", "cat": "subprime", "blurb": "Collects and provides information on payday loans, installment loans, auto loans (and leasing), check cashing.", "web": "https://www.clarityservices.com", "phone": "866-390-3118", "addr": "P.O. Box 16, Allen, TX 75013", "freeze": true},
  {"id": "datax-ltd", "name": "DataX, Ltd.", "cat": "subprime", "blurb": "Collects and provides consumer payment history on payday and installment loans, subprime credit cards and other products.", "web": "https://www.datax.com", "phone": "800-295-4790", "addr": "P.O. Box 740125, Atlanta, GA 30374", "freeze": true},
  {"id": "factortrust", "name": "FactorTrust", "cat": "subprime", "blurb": "Collects loan performance information on nonprime consumers to provide predictive credit data, analytics and risk management.", "web": "https://www.factortrust.com", "phone": "844-773-3321", "addr": "P.O. Box 390, Woodlyn, PA 19094", "freeze": true},
  {"id": "microbilt", "name": "MicroBilt", "cat": "subprime", "blurb": "Collects recurring bill repayment data, such as monthly billing data from rent, utility, phone plans, car insurance.", "web": "https://www.microbilt.com", "phone": "888-222-7621", "addr": "P.O. Box 440693, Kennesaw, GA 30160", "freeze": true},
  {"id": "teletrack", "name": "Teletrack", "cat": "subprime", "blurb": "Collects consumer information about, and provides data to, payday lenders, rent-to-own businesses, furniture stores.", "web": "https://consumers.teletrack.com", "phone": "877-309-5226", "addr": "P.O. Box 740008, Atlanta, GA 30374", "freeze": true},
  {"id": "innovis", "name": "Innovis", "cat": "supplementary", "blurb": "Provides credit and identity verification data", "web": "https://www.innovis.com/personal/creditReport", "phone": "800-540-2505", "addr": "P.O. Box 530088, Atlanta, GA 30353-0088", "freeze": true},
  {"id": "lexisnexis-risk-solutions", "name": "LexisNexis Risk Solutions", "cat": "supplementary", "blurb": "Provides information to financial institutions, insurance carriers, healthcare providers and government agencies.", "web": "https://consumer.risk.lexisnexis.com/consumer", "phone": "866-897-8126", "addr": "P.O. Box 105108, Atlanta, GA 30348-5108", "freeze": true},
  {"id": "sagestream-llc", "name": "SageStream, LLC", "cat": "supplementary", "blurb": "Collects information from, and provides supplementary consumer reports to, auto lenders, credit card issuers.", "web": "https://www.sagestreamllc.com/", "phone": "866-897-8126", "addr": "P.O. Box 105108, Atlanta, GA 30348-5109", "freeze": true},
  {"id": "national-consumer-telecom-utilities-exchange", "name": "National Consumer Telecom & Utilities Exchange (NCTUE)", "cat": "telecom", "blurb": "This consortium of member companies collects and shares information on new telecom and utility connect requests.", "web": "https://www.nctue.com/consumers", "phone": "866-349-5185", "addr": "P.O. Box 105161, Atlanta, GA 30348", "freeze": true},
  {"id": "the-retail-equation", "name": "The Retail Equation", "cat": "retail", "blurb": "Monitors and reports to merchants retail product return and suspected exchange fraud and abuse", "web": "https://www.theretailequation.com/", "phone": "800-652-2331", "addr": "P.O. Box 51373, Irvine, CA 92619-1373", "freeze": false},
  {"id": "central-credit-llc", "name": "Central Credit, LLC", "cat": "gaming", "blurb": "Provides consumer credit information to a network of gaming establishments when casino operators extend lines of credit.", "web": "https://www.everi.com/fintech/casino/central-credit/", "phone": "800-566-2087", "addr": "7250 S Tenaya Way Suite 100, Las Vegas, NV 89113", "freeze": false},
  {"id": "ncc", "name": "NCC (National Cred-A-Chek, Inc.)", "cat": "gaming", "blurb": "Provides consumer data to help gaming establishments manage credit and fraud risks", "web": "https://www.nccreports.com/index.php?request", "phone": "800-421-2168", "addr": "3770 4th Ave, San Diego, CA 92103", "freeze": false},
  {"id": "vip-preferred", "name": "VIP Preferred", "cat": "gaming", "blurb": "Provides consumer data to casinos (in-person and online), online sports betting (sportsbooks and fantasy sports).", "web": "https://www.vippreferred.com/facta-report", "phone": "800-500-1973", "addr": "P.O. Box 480357, Niles, IL 60714-0357", "freeze": false},
];

export function getCra(id?: string | null): Cra {
  return CRAS.find((c) => c.id === id) ?? CRAS[1];
}

export function craCategoryLabel(id: CraCategory): string {
  return CRA_CATEGORIES.find((c) => c.id === id)?.label ?? id;
}

/** The commonly recommended first freeze pass. */
export const FREEZE_ESSENTIALS: string[] = [
  "equifax",
  "experian",
  "transunion",
  "innovis",
  "chex-systems-inc",
  "national-consumer-telecom-utilities-exchange",
];

export const FREEZE_COUNT = CRAS.filter((c) => c.freeze).length;
