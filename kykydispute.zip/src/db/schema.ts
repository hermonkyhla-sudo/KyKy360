import {
  integer,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  author: text("author").notNull(),
  quote: text("quote").notNull(),
  rating: integer("rating").notNull().default(5),
  tag: text("tag").notNull().default("Verified user"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const blogPosts = pgTable("blog_posts", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  category: text("category").notNull(),
  title: text("title").notNull(),
  excerpt: text("excerpt").notNull(),
  image: text("image").notNull(),
  readMins: integer("read_mins").notNull().default(6),
  publishedAt: timestamp("published_at").notNull().defaultNow(),
});

export const leads = pgTable("leads", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  goal: text("goal").notNull(),
  plan: text("plan").notNull().default("KyKy Credit Monitoring"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const freezes = pgTable("freezes", {
  id: serial("id").primaryKey(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  /** CRA id from the directory, e.g. "equifax" or "chex-systems-inc". */
  cra: text("cra").notNull(),
  letterText: text("letter_text").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const disputes = pgTable("disputes", {
  id: serial("id").primaryKey(),
  fullName: text("full_name").notNull(),
  bureau: text("bureau").notNull(),
  category: text("category").notNull(),
  creditor: text("creditor").notNull(),
  accountRef: text("account_ref").notNull().default(""),
  note: text("note").notNull().default(""),
  letterText: text("letter_text").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
