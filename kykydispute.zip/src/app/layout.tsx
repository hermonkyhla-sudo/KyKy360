import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "KyKyDispute | DIY AI Credit Repair Software & Dispute Letters",
  description:
    "AI credit repair that works. KyKyDispute creates legally-compliant dispute letters in seconds, mails them for you, and tracks results across all 3 bureaus — with a 110% money-back guarantee.",
  keywords: [
    "AI credit repair",
    "credit repair software",
    "dispute letters",
    "DIY credit repair",
    "FICO score",
    "credit monitoring",
  ],
  openGraph: {
    title: "KyKyDispute | DIY Financial Tool | AI Finances",
    description:
      "Your ultimate DIY credit repair dispute assistant tool powered by AI with a 110% money-back guarantee.",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=Geist:wght@300..900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-white text-ink antialiased">{children}</body>
    </html>
  );
}
