import { NextResponse } from "next/server";
import { db } from "@/db";
import { freezes } from "@/db/schema";
import { FREEZE_COUNT, getCra } from "@/lib/cras";
import { generateFreezeLetter } from "@/lib/letter";

export async function GET() {
  return NextResponse.json({
    freezeCapableCompanies: FREEZE_COUNT,
    note: "A security freeze is free under the FCRA and must be placed by each consumer reporting company that maintains a file on you.",
  });
}

export async function POST(req: Request) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const { fullName, email, cra } = (body ?? {}) as Record<string, string>;

  if (!fullName?.trim() || !email?.trim()) {
    return NextResponse.json(
      { error: "Name and email are required." },
      { status: 400 },
    );
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
    return NextResponse.json(
      { error: "Please enter a valid email address." },
      { status: 400 },
    );
  }

  const company = getCra(cra);

  if (!company.freeze) {
    return NextResponse.json(
      {
        error: `${company.name} does not offer a security freeze. You can still request your free report and file a dispute with them.`,
      },
      { status: 422 },
    );
  }

  const letterText = generateFreezeLetter({
    fullName: fullName.trim(),
    cra: company.id,
  });

  try {
    const [row] = await db
      .insert(freezes)
      .values({
        fullName: fullName.trim().slice(0, 120),
        email: email.trim().slice(0, 190),
        cra: company.id,
        letterText,
      })
      .returning();

    return NextResponse.json({
      ok: true,
      id: row?.id ?? null,
      cra: {
        id: company.id,
        name: company.name,
        addr: company.addr,
        phone: company.phone,
        web: company.web,
      },
      letter: letterText,
    });
  } catch {
    return NextResponse.json({
      ok: true,
      id: null,
      cra: {
        id: company.id,
        name: company.name,
        addr: company.addr,
        phone: company.phone,
        web: company.web,
      },
      letter: letterText,
    });
  }
}
