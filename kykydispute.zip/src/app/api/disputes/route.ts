import { NextResponse } from "next/server";
import { db } from "@/db";
import { disputes } from "@/db/schema";
import { CRAS, craCategoryLabel, getCra } from "@/lib/cras";
import {
  ITEM_CATEGORIES,
  estimatedImpact,
  generateLetter,
} from "@/lib/letter";

export async function GET() {
  return NextResponse.json({
    cras: CRAS.map((c) => ({
      id: c.id,
      name: c.name,
      category: craCategoryLabel(c.cat),
      freeze: c.freeze,
    })),
    categories: ITEM_CATEGORIES.map((c) => ({ id: c.id, label: c.label })),
  });
}

export async function POST(req: Request) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const { fullName, cra, bureau, category, creditor, accountRef, note } =
    (body ?? {}) as Record<string, string>;

  const craId = (cra ?? bureau ?? "experian").toString();

  if (!fullName?.trim() || !category) {
    return NextResponse.json(
      { error: "Name and item type are required." },
      { status: 400 },
    );
  }

  const company = getCra(craId);
  const letterText = generateLetter({
    fullName: fullName.trim(),
    cra: company.id,
    category,
    creditor: creditor?.trim() ?? "",
    accountRef: accountRef?.trim() ?? "",
    note: note?.trim() ?? "",
  });

  try {
    const [row] = await db
      .insert(disputes)
      .values({
        fullName: fullName.trim().slice(0, 120),
        bureau: company.id,
        category,
        creditor: (creditor ?? "Unknown furnisher").trim().slice(0, 160),
        accountRef: (accountRef ?? "").trim().slice(0, 24),
        note: (note ?? "").trim().slice(0, 600),
        letterText,
      })
      .returning();

    return NextResponse.json({
      ok: true,
      id: row?.id ?? null,
      cra: { id: company.id, name: company.name, addr: company.addr },
      letter: letterText,
      impact: estimatedImpact(category),
    });
  } catch {
    // still return the letter so the demo always works
    return NextResponse.json({
      ok: true,
      id: null,
      cra: { id: company.id, name: company.name, addr: company.addr },
      letter: letterText,
      impact: estimatedImpact(category),
    });
  }
}
