import { NextResponse } from "next/server";
import { db } from "@/db";
import { leads } from "@/db/schema";

export async function POST(req: Request) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const { name, email, goal, plan } = (body ?? {}) as Record<string, string>;

  if (!name?.trim() || !email?.trim()) {
    return NextResponse.json(
      { error: "Name and email are required." },
      { status: 400 },
    );
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
    return NextResponse.json(
      { error: "Please enter a valid email address." },
      { status: 400 },
    );
  }

  try {
    const [row] = await db
      .insert(leads)
      .values({
        name: name.trim().slice(0, 120),
        email: email.trim().slice(0, 190),
        goal: (goal ?? "Improve my credit score").trim().slice(0, 240),
        plan: (plan ?? "KyKy Credit Monitoring").trim().slice(0, 120),
      })
      .returning();
    return NextResponse.json({ ok: true, id: row?.id ?? null });
  } catch {
    return NextResponse.json(
      { error: "We couldn't save your request. Please try again." },
      { status: 500 },
    );
  }
}
