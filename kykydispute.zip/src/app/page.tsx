import Blog from "@/components/Blog";
import DisputeLab from "@/components/DisputeLab";
import Features from "@/components/Features";
import FreezeCenter from "@/components/FreezeCenter";
import Hero from "@/components/Hero";
import HowItWorks from "@/components/HowItWorks";
import IOSBand from "@/components/IOSBand";
import PainPoints from "@/components/PainPoints";
import Social from "@/components/Social";
import Start from "@/components/Start";
import Footer from "@/components/Footer";

// Reviews, guides and leads are served live from Postgres.
export const dynamic = "force-dynamic";

export default function HomePage() {
  return (
    <main>
      <Hero />
      <PainPoints />
      <IOSBand />
      <HowItWorks />
      <Features />
      <DisputeLab />
      <FreezeCenter />
      <Social />
      <Start />
      <Blog />
      <Footer />
    </main>
  );
}
